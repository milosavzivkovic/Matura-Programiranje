﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace arheoloska_nalazista
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        SqlConnection konekcija;
        SqlCommand komanda;
        SqlDataAdapter da;
        DataTable dt;
        void Konekcija()
        {
            konekcija = new SqlConnection();
            konekcija.ConnectionString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = ""Antikviteti i lokacije""; Integrated Security = True;";
            komanda = new SqlCommand();
            komanda.Connection = konekcija;
            dt = new DataTable();
            da = new SqlDataAdapter();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            numericUpDown1.Minimum = 2000;
            numericUpDown1.Maximum = 2023;
            numericUpDown2.Minimum = 1;
            numericUpDown2.Maximum = 100;
            dataGridView1.Columns[0].HeaderText = "GRAD";
            dataGridView1.Columns[1].HeaderText = "BROJ ANTIKVITETA";
            dataGridView1.Columns[0].Width = (dataGridView1.Width - dataGridView1.RowHeadersWidth) / 2;
            dataGridView1.Columns[1].Width = (dataGridView1.Width - dataGridView1.RowHeadersWidth) / 2;
        }
        void analiza()
        {
            Konekcija();
            string select = "SELECT gradovi.ime_grada, COUNT(antikviteti.antikvitetID)";
            string from = "FROM (gradovi inner join lokaliteti ON gradovi.gradID=lokaliteti.gradID)" +
                "INNER JOIN ANTIKVITETI ON ANTIKVITETI.lokalitetID=LOKALITETI.lokalitetID";
            string where = "WHERE ANTIKVITETI.datum_pronalaska>@godina";
            string group = "group by gradovi.ime_grada";
            string having = "HAVING COUNT(*)>@broj_antikviteta";
            komanda.Parameters.AddWithValue("@godina", numericUpDown1.Value.ToString());
            komanda.Parameters.AddWithValue("@broj_antikviteta", numericUpDown2.Value);
            komanda.CommandText = select + " " + from + " " + where + " " + group + " " + having;
            da.SelectCommand = komanda;
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            analiza();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            analiza();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series["Arheologija"].IsValueShownAsLabel = true;
            Random r = new Random();
            ArrayList grad = new ArrayList();
            ArrayList broj_antikviteta= new ArrayList();
            chart1.Series["Arheologija"].Points.Clear();
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                grad.Add(Convert.ToString(dataGridView1.Rows[i].Cells[0].Value));
                broj_antikviteta.Add(Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value));
                chart1.Series["Arheologija"].Points.AddXY(grad[i], broj_antikviteta[i]);
                chart1.Series["Arheologija"].Points[i].Color = Color.FromArgb(r.Next(255), r.Next(255), r.Next(255));
            }
        }
    }
}
