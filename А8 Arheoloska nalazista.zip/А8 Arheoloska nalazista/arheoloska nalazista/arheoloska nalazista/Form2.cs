﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace arheoloska_nalazista
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            pictureBox1.Image = Image.FromFile(@"./antikviteti\" + k + ".jpg");
            button2.Enabled = false;
        }
        SqlConnection konekcija;
        SqlCommand komanda;
        SqlDataAdapter da;
        DataTable dt;
        int k = 0;
        void Konekcija()
        {
            konekcija = new SqlConnection(); 
            konekcija.ConnectionString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = ""Antikviteti i lokacije""; Integrated Security = True;";
            komanda = new SqlCommand();
            komanda.Connection = konekcija;
            dt = new DataTable();
            da = new SqlDataAdapter();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            konekcija.Open();
            var image = new ImageConverter().ConvertTo(pictureBox1.Image, typeof(Byte[]));
            komanda.CommandText = "UPDATE TIPOVI_ANTIKVITETA SET tip=@tip,slika=@slika WHERE tipAntikvitetaID=@tipAntikvitetaID";
            komanda.Parameters.AddWithValue("@tip", textBox1.Text);
            komanda.Parameters.AddWithValue("@slika", image);
            komanda.Parameters.AddWithValue("@tipAntikvitetaID", label2.Text);
            try
            {
                komanda.ExecuteNonQuery();
                MessageBox.Show("Podaci izmenjeni u bazi!");
            }
            catch
            {
                MessageBox.Show("Greska!");
            }
            finally
            {
                konekcija.Close();
                Form2_Load(sender, e);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Konekcija();
            komanda.CommandText = "SELECT * FROM TIPOVI_ANTIKVITETA";
            da.SelectCommand = komanda;
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            textBox1.Text = dt.Rows[k][1].ToString();
            label2.Text = dt.Rows[k][0].ToString();
        }
        void napred_nazad()
        {
            if (k > 0 && k < dt.Rows.Count - 1)
            {
                button2.Enabled = true;
                button3.Enabled = true;
            }
            else if (k == 0)
            {
                button2.Enabled = false;
                button3.Enabled = true;
            }
            else
            {
                button2.Enabled = true;
                button3.Enabled = false;
            }
            pictureBox1.Image = Image.FromFile(@"./antikviteti\" + (k + 1) + ".jpg");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (k < dt.Rows.Count - 1)
                k++;
            Form2_Load(sender, e);
            napred_nazad();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (k > 0)
                k--;
            Form2_Load(sender, e);
            napred_nazad();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.InitialDirectory = Path.Combine(Application.StartupPath, @"antikviteti");
            openFileDialog1.Filter = "Format slike|*.jpg;|*png;|*jpeg";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                pictureBox1.Load(openFileDialog1.FileName);
        }
    }
}
