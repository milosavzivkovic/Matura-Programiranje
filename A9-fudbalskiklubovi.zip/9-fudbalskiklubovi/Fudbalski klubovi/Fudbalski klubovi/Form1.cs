﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Fudbalski_klubovi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Text = "The name of the game";
        }

        SqlConnection konekcija;
        SqlCommand komanda, komanda1,komanda2, komanda3,komanda4,komanda5,komanda6;
        DataTable dt1,dt2,dt3,dt4,dt5,dt6,dt7;

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Konekcija();
            listView1.Items.Clear();
            listView1.Columns.Add("Stadion", 380);
            listView1.Columns.Add("Domaća ekipa", 100);
            listView1.Columns.Add("Golovi domaćina", 100);
            listView1.Columns.Add("Golovi gostiju", 100);
            listView1.Columns.Add("Gostojuća ekipa", 100);
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            //uzimamo podatke o stadionu,domacoj ekipi,golovima domacina i gosta
            string select = "SELECT Stadion.Naziv,KLUB.NazivKluba, UTAKMICA.GolovaDomacin,UTAKMICA.GolovaGost";
            string from = "FROM (Stadion INNER JOIN Klub ON Stadion.StadionID=KLUB.StadionID)INNER JOIN Utakmica ON Utakmica.DomacinID=KLUB.KlubID";
            string where = "WHERE DatumIgranja=@datum";

            komanda5.Parameters.AddWithValue("@datum", dateTimePicker1.Value.ToString("MM.dd.yyyy"));
             komanda5.CommandText = select + " " + from + " " + where;
            da.SelectCommand = komanda5;
            da.Fill(dt6);

            foreach (DataRow row in dt6.Rows)
            {
                string[] podaci = {row[0].ToString(),row[1].ToString() , row[2].ToString(),row[3].ToString()," " };
                ListViewItem stavka = new ListViewItem(podaci);
                listView1.Items.Add(stavka);
            }
            //uzimamo podatke o gostima
            string select1 = "SELECT KLUB.NazivKluba";
            string from1 = "FROM Klub INNER JOIN Utakmica ON Utakmica.GostID=KLUB.KlubID";
            string where1 = "WHERE DatumIgranja=@datum1";
            komanda6.Parameters.AddWithValue("@datum1", dateTimePicker1.Value.ToString("MM.dd.yyyy"));
            komanda6.CommandText = select1 + " " + from1 + " " + where1;
            da.SelectCommand = komanda6;
            da.Fill(dt7);
            string []a= new string[100];

            for (int i = 0; i < dt7.Rows.Count; i++)
            {
                string kombo3 = dt7.Rows[i][0].ToString();
                a[i] = kombo3;
                
            }
            //pozicioniranje
            
            string []b= new string[]{"","","","",""};
            
            for(int i=0;i<100;i++)
            {
                ListViewItem stavka1 = new ListViewItem(b);
                listView1.Items.Add(stavka1);
            }
          
            for (int j=0;j<50;j++)
            {
                listView1.Items[j].SubItems[4].Text = a[j];
            }
      
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //resetovanje pretrage
            pictureBox1.Image = Image.FromFile(@"slike\logo.png");
            comboBox2.Enabled = false;
            comboBox3.Enabled = false;
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            label5.Text = "";
            linkLabel1.Text="";
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //kliklom na linklabel vodi nas na link
            Konekcija();
            string select = "SELECT Klub.Sajt";
            string from = "FROM Klub";
            string where = "WHERE Klub.NazivKluba=@Klub";
            komanda4.Parameters.AddWithValue("@Klub", comboBox3.Text);
            komanda4.CommandText = select + " " + from + " " + where;
            da.SelectCommand = komanda4;
            da.Fill(dt5);

            string tekst = dt5.Rows[0][0].ToString();
            System.Diagnostics.Process.Start(tekst);   
        }

        SqlDataAdapter da;

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //izborom kluba prikazujemo njegov grb,naziv grada,stadiona i sajt kluba
            Konekcija();
            string select = "SELECT Grad.Grad, Stadion.naziv,Klub.Sajt";
            string from = "FROM (Grad INNER JOIN Stadion ON Grad.GradID = Stadion.GradID) INNER JOIN Klub ON Klub.StadionID=Stadion.StadionID";
            string where = "WHERE Klub.NazivKluba=@Klub";
            komanda3.Parameters.AddWithValue("@Klub", comboBox3.Text);
            komanda3.CommandText = select + " " + from + " " + where;
            da.SelectCommand = komanda3;
            da.Fill(dt4);

            string tekst = dt4.Rows[0][0].ToString(); 
            string tekst1 = dt4.Rows[0][1].ToString();
            string tekst2 = dt4.Rows[0][2].ToString();
            label5.Text = tekst + "\n\n" + tekst1;
            linkLabel1.Text = tekst2;
            try
            {
  
                pictureBox1.Image = Image.FromFile(@"slike\" + comboBox3.Text + ".jpg");
             

            }
            catch
            {
                pictureBox1.Image = Image.FromFile(@"slike\default.jpg");
            }                        
        }

        void Konekcija()
        {
            konekcija = new SqlConnection();
            konekcija.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=fudbal;Integrated Security=True;";
            komanda = new SqlCommand();
            komanda1 = new SqlCommand();
            komanda2 = new SqlCommand();
            komanda3 = new SqlCommand();
            komanda4 = new SqlCommand();
            komanda5 = new SqlCommand();
            komanda6 = new SqlCommand();
            komanda.Connection = konekcija;
            komanda1.Connection = konekcija;
            komanda2.Connection = konekcija;
            komanda3.Connection = konekcija;
            komanda4.Connection = konekcija;
            komanda5.Connection = konekcija;
            komanda6.Connection = konekcija;
            dt1 = new DataTable();
            dt2 = new DataTable();
            dt3 = new DataTable();
            dt4 = new DataTable();
            dt5 = new DataTable();
            dt6 = new DataTable();
            dt7 = new DataTable();
            da = new SqlDataAdapter();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ako izabremeo grad prikazuju se svi klubovi iz tog grada a ako izaberemo "svi gradovi" combobox3 je onemogucen
            Konekcija();
            comboBox3.Enabled = true;
            comboBox3.Items.Clear();
            string select= "SELECT Klub.NazivKluba";    
            string from = "FROM (Grad INNER JOIN Stadion ON Grad.GradID = Stadion.GradID) INNER JOIN Klub ON Klub.StadionID=Stadion.StadionID";
            string where = "where Grad.Grad = @Grad";
            komanda2.Parameters.AddWithValue("@Grad", comboBox2.Text);
            if(comboBox2.SelectedIndex==0)
            {
                comboBox3.Enabled = false;

            }
                
            else
            {
                komanda2.CommandText = select + " " + from + " " + where;     
                da.SelectCommand = komanda2;
                da.Fill(dt3);

                for (int i = 0; i < dt3.Rows.Count; i++)
                {
                    string kombo3 = dt3.Rows[i][0].ToString();
                    comboBox3.Items.Add(kombo3);
                }
            }
           

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ako je izabrano sve drzave combobox sa gradovima je onemogucen u suprotnom prikazuju se svi gradovi iz combobox2
            Konekcija();
            comboBox2.Enabled = true;
            comboBox2.Items.Clear();
            if(comboBox1.SelectedIndex==0)
            {
                comboBox2.Enabled = false;
            }
            else
            {
                komanda1.CommandText = "SELECT Grad.grad FROM Grad INNER JOIN drzava ON Grad.DrzavaId=Drzava.DrzavaId where Drzava.naziv=@Drzava";
                komanda1.Parameters.AddWithValue("@Drzava", comboBox1.Text);


                da.SelectCommand = komanda1;
                da.Fill(dt2);
                comboBox2.Items.Add("Svi gradovi");
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    string kombo2 = dt2.Rows[i][0].ToString();
                    comboBox2.Items.Add(kombo2);
                }
            }
           

         
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           //prikaz svih drzava i logo FIFA kao i uputstvo aplikacije na 3. tabu
            Konekcija();
            komanda.CommandText = "SELECT Drzava.naziv FROM Drzava";
            da.SelectCommand = komanda;
            da.Fill(dt1);
            comboBox1.Items.Add("Sve države");
            
            for (int i=0;i<dt1.Rows.Count;i++)
            {
                string kombo1 = dt1.Rows[i][0].ToString();
                comboBox1.Items.Add(kombo1);
            }
            comboBox2.Enabled = false;
            
            pictureBox1.Image = Image.FromFile(@"slike\logo.png");
            label7.Text = "Na prvom tabu pomoću 3 kombo boksa možete izabrati klub\nza koji će vam izaći logo(grb) kluba, grad kluba, njegov stadion i link\npomoću kojeg možete otići do sajta kluba.\nNa drugom tabu izaberite datum i ispod će se prikazati sve utakmice\nodigrane tog datuma(Stadion domaćina,domaćin,golovi domaćina,golovi gostiju i gost).";
            label8.Text = "Aplikaciju su radili Nikola Krsmanovic i Veljko Kostovic.";
        }
    }
}
