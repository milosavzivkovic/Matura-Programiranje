﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Projekat
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            button1.Enabled = false;
            textBox1.Enabled =false;
        }
        // globalne promenjljive koje koristimo u vise funkcija
        SqlConnection konekcija;
        SqlCommand komanda1, komanda2, komanda3,komanda4;
        DataTable dt, dt1, dt2, dt3,dt4;
        SqlDataAdapter da;
        int iznos = 0;
        int ukupno=0;
        int red = 0;
        //dodatno popunjavanje liste
        private void button1_Click_1(object sender, EventArgs e)
        {
            Konekcija();
            try
            {
                if (iznos < Convert.ToInt32(textBox1.Text))
                {
                    Exception e1 =new Exception("Greska, ne mozete uplatiti vecu sumu nego sto dugujete");
                    throw e1;
                }
                DateTime t= DateTime.Now;
                string[] k1 = comboBox2.Text.Split(' ');
                komanda4.CommandText = " insert  into uplata(ugovorid, rata, iznos, datumuplate) values(@ugovori,@rata,@iznos,@datum)";
                komanda4.Parameters.AddWithValue("@ugovori", Convert.ToInt32(k1[2]));
                komanda4.Parameters.AddWithValue("@rata",Convert.ToInt32(red+1));
                komanda4.Parameters.AddWithValue("@iznos", Convert.ToInt32(textBox1.Text));
                komanda4.Parameters.AddWithValue("@datum", t);
                konekcija.Open();
                komanda4.ExecuteNonQuery();

                MessageBox.Show("Uspesno", "INFORMACIJA!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                red = 0;
                dt4.Rows.Clear();
                listView1.Items.Clear();
                dt3.Rows.Clear();
                iznos = 0;
                ukupno = 0;
            
                komanda3.CommandText = "Select rata, iznos, datumuplate from uplata where UgovorID=@ugovor";
                komanda3.Parameters.AddWithValue("@ugovor", Convert.ToInt32(k1[2]));
                da.SelectCommand = komanda3;
                da.Fill(dt3);
                listView1.Items.Add("Rata".PadRight(20) + "\t" + "Uplata".PadRight(25 - 4) + "\t" + "Datum".PadRight(45));

                for (int i = 0; i < dt3.Rows.Count; i++)
                {
                    red++;
                    string rata = dt3.Rows[i][0].ToString();
                    string[] datum1 = dt3.Rows[i][2].ToString().Split(' ');
                    string datum = datum1[0];
                    string uplata = dt3.Rows[i][1].ToString();
                    ukupno += Convert.ToInt32(uplata);
                    listView1.Items.Add(rata.PadRight(22) + "\t" + uplata.PadRight(25 - uplata.Length) + "\t" + datum.PadRight(45 - datum.Length));
                }
                komanda3.CommandText = "Select  UkupnaCenaAranzmana from Turisticki_aranzman where UgovorID=@ugovor1";
                komanda3.Parameters.AddWithValue("@ugovor1", Convert.ToInt32(k1[2]));
                da.SelectCommand = komanda3;
                da.Fill(dt4);
                label4.Text = "Ukupna cena " + dt4.Rows[0][0].ToString();
                iznos = Convert.ToInt32(dt4.Rows[0][0]) - ukupno;
                label5.Text = "Iznos duga " + iznos;
                if (iznos == 0)
                {
                    button1.Enabled = false;
                    textBox1.Enabled = false;
                }
                da.SelectCommand = komanda3;
                da.Fill(dt4);
            }
            catch ( Exception e1) { MessageBox.Show(e1.Message, "GRESKA!", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            catch
            {
                MessageBox.Show("Greska", "GRESKA!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //popunjavanje naziva mesta i ugvorora
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Konekcija();
            listView1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox2.Refresh();
            string[] k1 = comboBox1.Text.Split(',');
            komanda2.CommandText = "SELECT t.UgovorID, CONCAT (k.ime , ' ' , k.prezime) from Klijent k join Turisticki_aranzman t on t.KlijentID= k.KlijentID join Turisticka_destinacija d on d.DestinacijaID= t.DestinacijaID where d.NazivMesta = @mesto";
            komanda2.Parameters.AddWithValue("@mesto", k1[0].ToString());
            da.SelectCommand = komanda2;
            da.Fill(dt1);
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                comboBox2.Items.Add("(ugovor br. " + dt1.Rows[i][0].ToString() + " ) " + dt1.Rows[i][1].ToString());
            }
        } 
        //pokusaj rada kalendara i popunjavanje liste i ukupne cene
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Konekcija();
            dt4.Clear();
            button1.Enabled = true;
            textBox1.Enabled = true;
            iznos = 0;
            ukupno = 0;
            listView1.Items.Clear();
            string[] k1 = comboBox2.Text.Split(' ');
            komanda3.CommandText = "Select rata, iznos, datumuplate from uplata where UgovorID=@ugovor";
            komanda3.Parameters.AddWithValue("@ugovor", Convert.ToInt32(k1[2]));
            da.SelectCommand = komanda3;
            da.Fill(dt3);
            listView1.Items.Add("Rata".PadRight(20) + "\t" + "Uplata".PadRight(25 -4) + "\t" + "Datum".PadRight(45));
            for (int i = 0; i < dt3.Rows.Count; i++)
            {
                red++;
                string rata = dt3.Rows[i][0].ToString();
                string[] datum1 = dt3.Rows[i][2].ToString().Split(' ');
                string datum = datum1[0];
                string uplata = dt3.Rows[i][1].ToString();
                ukupno+= Convert.ToInt32(uplata);
                listView1.Items.Add(rata.PadRight(22) + "\t" + uplata.PadRight(25 - uplata .Length) + "\t" + datum.PadRight(45 - datum.Length));
            }
            komanda3.CommandText = "Select  UkupnaCenaAranzmana from Turisticki_aranzman where UgovorID=@ugovor1";
            komanda3.Parameters.AddWithValue("@ugovor1", Convert.ToInt32(k1[2]));
            da.SelectCommand = komanda3;
            da.Fill(dt4);
            label4.Text = "Ukupna cena " + dt4.Rows[0][0].ToString();
            iznos= Convert.ToInt32( dt4.Rows[0][0])- ukupno;
            label5.Text = "Iznos duga " + iznos;
            if(iznos==0)
            {
                button1.Enabled = false;
                textBox1.Enabled= false;
            }
            komanda1.CommandText = "SELECT DatumPolaska, DatumPovratka FROM Turisticki_aranzman where UgovorID=@ugovor1";
            komanda1.Parameters.AddWithValue("@ugovor1", Convert.ToInt32(k1[2]));
            da.SelectCommand = komanda1;
            da.Fill(dt2);
            DateTime d = new DateTime();
            DateTime d1 = new DateTime();
            d = Convert.ToDateTime(dt2.Rows[0][0].ToString());
            d1 = Convert.ToDateTime(dt2.Rows[0][1].ToString());
            monthCalendar1.SelectionStart = d;
            monthCalendar1.SelectionEnd = d1;
        }
        public void Konekcija()
            {
            konekcija = new SqlConnection();
            konekcija.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Turisticka agencija\";Integrated Security=True;";
            komanda1 = new SqlCommand();
            komanda1.Connection = konekcija;
            komanda2 = new SqlCommand();
            komanda2.Connection = konekcija;
            komanda3 = new SqlCommand();
            komanda3.Connection = konekcija;
            komanda4= new SqlCommand();
            komanda4.Connection = konekcija;
            da = new SqlDataAdapter();
            dt = new DataTable();
            dt1 = new DataTable();
            dt2 = new DataTable();
            dt3 = new DataTable();
            dt4 = new DataTable();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
           Konekcija();
            komanda1.CommandText = "SELECT NazivMesta, drzava from Turisticka_destinacija";
            da.SelectCommand = komanda1;
            da.Fill(dt);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBox1.Items.Add(dt.Rows[i][0].ToString() + "," + dt.Rows[i][1].ToString());
            }
        }
    }
}
