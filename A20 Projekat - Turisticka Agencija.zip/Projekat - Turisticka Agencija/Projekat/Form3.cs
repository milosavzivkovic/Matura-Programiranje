﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projekat
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        // globalne promenjljive koje koristimo u vise funkcija
        SqlConnection konekcija;
        SqlCommand komanda1;
        DataTable dt, dt1, dt2;
        SqlDataAdapter da;
        int iznos = 0;
        int ukupno = 0;
        public void Konekcija()
        {
            konekcija = new SqlConnection();
            konekcija.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Turisticka agencija\";Integrated Security=True;";
            komanda1 = new SqlCommand();
            komanda1.Connection = konekcija;
            da = new SqlDataAdapter();
            dt = new DataTable();
            dt1 = new DataTable();
            dt2 = new DataTable();
        }
        // spisak putnika i dugovanja (pod komentarom je datum za narednih 15 dana ali u bazi nemaju putovanja skorije)
        private void Form3_Load(object sender, EventArgs e)
        {
            Konekcija();
            //DateTime dt1 = DateTime.Now;
            //DateTime dt2 = DateTime.Now.AddDays(15);
            DateTime d = Convert.ToDateTime("1/1/2023");
            DateTime d1 = Convert.ToDateTime("12/12/2023");
            komanda1.CommandText = "SELECT ta.UgovorID, k.Ime, k.Prezime, td.NazivMesta AS 'Destinacija', ta.DatumPolaska AS 'Polazak', ta.UkupnaCenaAranzmana AS 'Cena'  FROM Turisticki_aranzman ta JOIN Klijent k ON ta.KlijentID=k.KlijentID JOIN Turisticka_destinacija td ON ta.DestinacijaID =td.DestinacijaID WHERE ta.DatumPolaska BETWEEN @d AND @d1";
            komanda1.Parameters.AddWithValue("@d", d);
            komanda1.Parameters.AddWithValue("@d1", d1);
            da.SelectCommand=komanda1;
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns.Add("Placeno", "Placeno");
            dataGridView1.Columns.Add("Dugovanje", "Dugovanje");
            komanda1.Parameters.Clear();
            for(int i = 0; i < dataGridView1.Rows.Count-1; i++)
            {
                dt1.Clear();
                iznos = 0;
                ukupno = 0;
                komanda1.CommandText = "Select rata, iznos from uplata where UgovorID=@ugovor";
                komanda1.Parameters.AddWithValue("@ugovor", Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value));
                da.SelectCommand = komanda1;
                da.Fill(dt1);
                for (int j = 0; j < dt1.Rows.Count; j++)
                {
                    string uplata = dt1.Rows[j][1].ToString();
                    ukupno += Convert.ToInt32(uplata);
                }
                komanda1.Parameters.Clear();
                iznos = Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value) - ukupno;
                dataGridView1.Rows[i].Cells[6].Value = ukupno;
                dataGridView1.Rows[i].Cells[7].Value = iznos;
                if(iznos<0)
                {
                    dataGridView1.Rows[i].Cells[7].Style.BackColor = Color.Green;
                } else
                {
                    if(iznos>0)
                    {
                        dataGridView1.Rows[i].Cells[7].Style.BackColor = Color.Red;
                    }
                }
            }
        }
    }
}