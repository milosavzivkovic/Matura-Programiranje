﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;

namespace dvd_kolekcija
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Korekcija podataka - Producentska kuca";
        }
        SqlConnection konekcija;
        DataTable dt;
        SqlDataAdapter da;
        SqlCommand komanda;
        void Konekcija()
        {
            konekcija = new SqlConnection(); 
            konekcija.ConnectionString = @"Data Source = (localdb)\ProjectModels; Initial Catalog = ""DVD kolekcija""; Integrated Security = True;";
            komanda = new SqlCommand();
            komanda.Connection = konekcija;
            dt = new DataTable();
            da = new SqlDataAdapter();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Konekcija();
            listBox1.Items.Clear();
            ArrayList lista=new ArrayList();
            komanda.CommandText = "SELECT ProducentID,Ime,Email FROM producent ORDER BY ProducentID asc";
            da.SelectCommand = komanda;
            da.Fill(dt);
            int i;
            textBox1.Text = dt.Rows[0][0].ToString();
            textBox2.Text = dt.Rows[0][1].ToString();
            textBox3.Text = dt.Rows[0][2].ToString();
            for (i = 0; i < dt.Rows.Count; i++)
            {
                string producent = dt.Rows[i][0].ToString();
                string ime = dt.Rows[i][1].ToString();
                string email = dt.Rows[i][2].ToString();
                listBox1.Items.Add(producent.PadLeft(5 - producent.Length) + "\t\t" + ime.PadRight(40 - ime.Length) + "\t\t" + email.PadRight(30 - email.Length));
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = dt.Rows[listBox1.SelectedIndex][0].ToString();
            textBox2.Text = dt.Rows[listBox1.SelectedIndex][1].ToString();
            textBox3.Text = dt.Rows[listBox1.SelectedIndex][2].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Konekcija();
            komanda.CommandText = "UPDATE Producent SET ime=@ime,email=@email WHERE producentID=@producentID";
            komanda.Parameters.AddWithValue("@ime", textBox2.Text);
            komanda.Parameters.AddWithValue("@email", textBox3.Text);
            komanda.Parameters.AddWithValue("@producentID", textBox1.Text);
            try
            {
                konekcija.Open();
                komanda.ExecuteNonQuery();
                MessageBox.Show("Uspesna izmena");
            }
            catch
            {
                MessageBox.Show("Greska");
            }
            finally
            {
                konekcija.Close();
            }
            Form1_Load(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Analiza analiza = new Analiza();
            analiza.ShowDialog();
        }
    }
}
