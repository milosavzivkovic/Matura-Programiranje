﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace dvd_kolekcija
{
    public partial class Analiza : Form
    {
        public Analiza()
        {
            InitializeComponent();
            dataGridView1.RowHeadersVisible = false;
        }
        SqlConnection konekcija;
        DataTable dt;
        SqlDataAdapter da;
        SqlCommand komanda;
        void Konekcija()
        {
            konekcija = new SqlConnection();
            konekcija.ConnectionString = @"Data Source = (localdb)\ProjectModels; Initial Catalog = ""DVD kolekcija""; Integrated Security = True;";
            komanda = new SqlCommand();
            komanda.Connection = konekcija;
            dt = new DataTable();
            da = new SqlDataAdapter();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series["Producent"].IsValueShownAsLabel=true;
            Random r = new Random();
            ArrayList producent = new ArrayList();
            ArrayList broj_filmova=new ArrayList();
            chart1.Series["Producent"].Points.Clear();
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                producent.Add(Convert.ToString(dataGridView1.Rows[i].Cells[0].Value));
                broj_filmova.Add(Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value));
                chart1.Series["Producent"].Points.AddXY(producent[i],broj_filmova[i]); 
                chart1.Series["Producent"].Points[i].Color =Color.FromArgb(r.Next(255), r.Next(255), r.Next(255));
                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
            }
        }

        private void Analiza_Load(object sender, EventArgs e)
        {
            Konekcija();
            string select = "SELECT producent.Ime AS PRODUCENT, COUNT (producirao.filmID)" +
                " AS 'BROJ FILMOVA'";//apostrofi za alijase koji imaju 2 ili vise reci
            string from = "FROM producent INNER JOIN producirao ON " +
                "producirao.producentID=producent.producentID";
            string group = "GROUP BY producent.Ime";
            komanda.CommandText = select + " " + from + " " + group;
            da.SelectCommand = komanda;
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 3 * (dataGridView1.Width/* - dataGridView1.RowHeadersWidth*/) / 4;
            dataGridView1.Columns[1].Width = (dataGridView1.Width /*- dataGridView1.RowHeadersWidth*/) / 4;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
