﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.Runtime.Remoting.Contexts;

namespace Biblioteka1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        SqlConnection konekcija;
        SqlDataAdapter da;
        DataTable dt;
        SqlCommand komanda;
        void Konekcija()
        {
            konekcija = new SqlConnection();
            komanda = new SqlCommand();
            dt = new DataTable();
            da = new SqlDataAdapter();
            konekcija.ConnectionString = @"Data Source = (localdb)\ProjectModels; Initial Catalog = Biblioteka; Integrated Security = True;";
            //konekcija.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Biblioteka 2;Integrated Security=True;";
            komanda.Connection = konekcija;


        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Konekcija();
            listView1.Clear();
            listView1.Columns.Add("CitalacID", 100);
            listView1.Columns.Add("Maticni_broj", 100);
            listView1.Columns.Add("Ime", 100);
            listView1.Columns.Add("Prezime", 100);
            listView1.Columns.Add("Adresa", 100);
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            komanda.CommandText = "SELECT citalacid,maticni_broj,ime,prezime,adresa FROM Citalac";
            da.SelectCommand = komanda;
            da.Fill(dt);
            foreach(DataRow row in dt.Rows)
            {
                string[] podaci =
                {
                    row[0].ToString(),row[1].ToString(),row[2].ToString(),row[3].ToString(),row[4].ToString()
                };
                ListViewItem stavka = new ListViewItem(podaci);
                listView1.Items.Add(stavka);
            }
            komanda.CommandText = "SELECT * FROM Citalac";
            da.SelectCommand = komanda;
            da.Fill(dt);
            for(int i=0;i<dt.Rows.Count;i++)
            {
                string kombo = dt.Rows[i][0] + "-" + dt.Rows[i][2] + " " + dt.Rows[i][3];
                comboBox1.Items.Add(kombo);
            }
        }
        int Postoji(int id,DataTable dt)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
                if (id == Convert.ToInt32(dt.Rows[i][0]))
                    return 1;
            return 0;
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text!="")
            {
                Konekcija();
                int id = Convert.ToInt32(textBox1.Text);
                komanda.CommandText = "SELECT citalacid, maticni_broj, ime, prezime, adresa FROM Citalac WHERE citalacid=@id";
                komanda.Parameters.AddWithValue("@id", id);
                da.SelectCommand = komanda;
                da.Fill(dt);
                if(Postoji(id,dt)==1)
                {
                    textBox2.Text = dt.Rows[0][1].ToString();
                    textBox3.Text = dt.Rows[0][2].ToString();
                    textBox4.Text = dt.Rows[0][3].ToString();
                    textBox5.Text = dt.Rows[0][4].ToString();
                    textBox2.ReadOnly = textBox3.ReadOnly = textBox4.ReadOnly = textBox5.ReadOnly = true;
                }
                else
                {
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox2.ReadOnly = textBox3.ReadOnly = textBox4.ReadOnly = textBox5.ReadOnly = false;
                }
            }
            else
            {
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox2.ReadOnly = textBox3.ReadOnly = textBox4.ReadOnly = textBox5.ReadOnly = false;
            }


        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox1.Text = item.SubItems[0].Text;
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                textBox4.Text = item.SubItems[3].Text;
                textBox5.Text = item.SubItems[4].Text;
                button1.Enabled = false;
            }
            else
            {
                textBox1.Text = string.Empty;
                textBox2.Text = string.Empty;
                textBox3.Text = string.Empty;
                textBox4.Text = string.Empty;
                textBox5.Text = string.Empty;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Konekcija();
            string insert = "INSERT INTO Citalac(citalacid, maticni_broj, ime, prezime, adresa)";
            string values = "VALUES (@id, @mat, @ime, @prezime, @adresa)";
            komanda.Parameters.AddWithValue("@id", Convert.ToInt32(textBox1.Text));
            komanda.Parameters.AddWithValue("@mat", textBox2.Text);
            komanda.Parameters.AddWithValue("@ime", textBox3.Text);
            komanda.Parameters.AddWithValue("@prezime", textBox4.Text);
            komanda.Parameters.AddWithValue("@adresa", textBox5.Text);
            komanda.CommandText = insert + values;
            try
            {
                konekcija.Open();
                komanda.ExecuteNonQuery();
                MessageBox.Show(String.Format("Citalac sa id={0} dodat u bazu",textBox1.Text));
            }
            catch
            {
                MessageBox.Show("Greška!");
                textBox1.Text = "";
                textBox1.Focus();
            }
            finally
            {
                konekcija.Close();
                Form1_Load(sender, e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Konekcija();
            string kombo = comboBox1.Text;
            string[] niz = kombo.Split('-');
            int min = Convert.ToInt32(numericUpDown1.Value);
            int max = Convert.ToInt32(numericUpDown2.Value);
            string select= "SELECT ime+' '+prezime AS 'Ime i prezime', YEAR(datum_uzimanja) " +
                "AS 'Godina', COUNT(datum_uzimanja) AS 'Broj iznajmljivanja'," +
                "COUNT(*) - COUNT(datum_vracanja) AS 'Nije vraceno'";
            string from = "FROM Citalac INNER JOIN Na_citanju ON Citalac.CitalacID=Na_citanju.CitalacID";
            string where = "WHERE (YEAR(datum_uzimanja) BETWEEN @min AND @max) AND (Citalac.CitalacID=@id)";
            string group = "GROUP BY ime+' '+prezime, YEAR(datum_uzimanja)";
            komanda.CommandText = select + " " + from + " " + where + " " + group;
            komanda.Parameters.AddWithValue("@id", niz[0]);
            komanda.Parameters.AddWithValue("@min", min);
            komanda.Parameters.AddWithValue("@max", max);
            da.SelectCommand = komanda;
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            try
            {
                konekcija.Open();
                komanda.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Greška");
            }
            finally
            {
                konekcija.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            chart1.Series["Uzeto"].IsValueShownAsLabel = true;
            chart1.Series["Uzeto"].Points.Clear();

            chart1.Series["Vraćeno"].IsValueShownAsLabel = true;
            chart1.Series["Vraćeno"].Points.Clear();

            ArrayList godina=new ArrayList();
            ArrayList iznajmljen = new ArrayList();
            ArrayList nije = new ArrayList();
            for(int i=0;i<dataGridView1.Rows.Count;i++)
            {
                godina.Add(dataGridView1.Rows[i].Cells[1].Value);
                iznajmljen.Add(dataGridView1.Rows[i].Cells[2].Value);
                nije.Add(dataGridView1.Rows[i].Cells[2].Value);
                chart1.Series["Uzeto"].Points.AddXY(godina[i], iznajmljen[i]);
                chart1.Series["Vraćeno"].Points.AddXY(godina[i], nije[i]);

            }
        }
    }
}
