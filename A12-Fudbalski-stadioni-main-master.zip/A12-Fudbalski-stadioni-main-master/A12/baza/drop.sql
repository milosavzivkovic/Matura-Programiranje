drop table takmicenje;
drop table utakmica;
drop table Drzave;
drop table grad;
drop table Stadion;
drop table klub; 