﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotelse_rezervacije
{
    public partial class Tutorial : Form
    {
        public Tutorial()
        {
            InitializeComponent();
        }

        private void Tutorial_Load(object sender, EventArgs e)
        {
            label2.Text = "Hotel vodi evidenciju o načinjenim rezervacijama i uplatama rezervisane usluge. \nKorisnik ugovarač (mušterija) može da rezerviše jednu i više soba željene strukture i pri tome navodi imena ostalih korisnika aranžmana(gosti).";
            label2.Text += "\nDugme Payment početne forme otvara formu Plaćanja na kojoj se vrši uplata rate aranžmana. \nIzborom broja ugovora iz odgovarajuće padajuće liste, u polju ispod liste se prikazuju podacio ugovaraču\n i aranžmanu: ime i prezime korisnika, početak i trajanje aranžmana, \nukupna cena, rok za izmirenje dugova i preostali iznos za plaćanje.";
            label2.Text += "\nKlikom na dugme Uplati vrši se uplata unetog iznosa.Da bi se izvršila \nuplata potrebno je pored broja ugovora odrediti i način i iznos uplate.";
            label2.Text += "\nDugme Booking sa početne forme otvara formu za pretragu slobodnih kapaciteta u \nzadatom periodu.Korisnik određuje u od kad do kad bi želeo da rezerviše sobu.\nNije neophodno da se odrede tačan početak i kraj boravka. Klikom na Pretraga kapaciteta prikazuju se podaci\no raspoloživim sobama(broj sobe, tip sobe i sprat).";
            label2.Text += "\nNa trećoj stranici koja se otvara klikom na dugme Tutorial na početnoj formi, \nnalazi se kratka prateća tehnička dokumentacija sa opisom strukture i funkcionalnosti aplikacije.";
            label2.Text += "\nČetvrto dugme(Exit) na početnoj formi, zatvara celu aplikaciju.";
        }
    }
}
