﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace hotelse_rezervacije
{
    public partial class Placanje : Form
    {
        public Placanje()
        {
            InitializeComponent();
        }
        SqlConnection konekcija;
        SqlConnection konekcija1;
        SqlDataAdapter da;
        SqlCommand komanda;
        SqlCommand komanda1;
        DataTable dt1, dt2;
        int suma=0;
        void Konekcija()
        {
            konekcija = new SqlConnection();
            //konekcija.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=""Hotelske rezervacije"";Integrated Security=True;";
            konekcija.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=hoteli;Integrated Security=True;";
            konekcija1 = new SqlConnection();
            //konekcija1.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=""Hotelske rezervacije"";Integrated Security=True;";
            konekcija1.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=hoteli;Integrated Security=True;";
            komanda = new SqlCommand();
            komanda.Connection = konekcija;
            komanda1 = new SqlCommand();
            komanda1.Connection = konekcija;
            dt1 = new DataTable();
            dt2 = new DataTable();
            da = new SqlDataAdapter();
        }
        private void Placanje_Load(object sender, EventArgs e)
        {
            Konekcija();
            komanda.CommandText = "SELECT rezervacija_id FROM rezervacija";
            da.SelectCommand = komanda;
            da.Fill(dt1);
            //combobox1
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                if(!comboBox1.Items.Contains(dt1.Rows[i][0]))
                comboBox1.Items.Add(dt1.Rows[i][0]);
            }
            dt1.Clear();
            //combobox2
            komanda.CommandText = "SELECT nacin_placanja FROM nacin_placanja";
            da.SelectCommand = komanda;
            da.Fill(dt2);
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                if (!comboBox2.Items.Contains(dt2.Rows[i][0]))
                    comboBox2.Items.Add(dt2.Rows[i][0]);
            }
            dt2.Clear();
        }
        int rezervacija_id;
        int dug;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listView1.Columns.Clear();
            Konekcija();
            rezervacija_id=Convert.ToInt32(comboBox1.Text);
            //odredjivanje koliko uplata je izvršeno za odredjenu rezervaciju
            komanda.CommandText = "SELECT COUNT(*) FROM uplata WHERE rezervacija_id=@rezervacija_id";
            komanda.Parameters.AddWithValue("@rezervacija_id", rezervacija_id);
            try
            {
                konekcija.Open();
                int proveri = Convert.ToInt32(komanda.ExecuteScalar());
                //provera da li je nesto uplaćeno do sada
                //ako je provera različita od 0 odredjuje se koliko je uplaćeno od sada
                if (proveri != 0)
                {
                    //odredjivanje sume koja je uplaćena'
                    komanda1.CommandText = "SELECT SUM(iznos) FROM uplata WHERE rezervacija_id=@rezervacija_id";
                    komanda1.Parameters.AddWithValue("@rezervacija_id", rezervacija_id);

                    try
                    {
                        konekcija1.Open();
                        suma = Convert.ToInt32(komanda1.ExecuteScalar());
                    }
                    catch
                    {
                        MessageBox.Show("Greška pri odredjivanju iznosa uplaćenog do sada", "GREŠKA");
                    }
                    finally
                    {
                        konekcija1.Close();
                    }
                }
                else
                    suma = 0;
            }
            catch
            {
                MessageBox.Show("Greška");
            }
            finally
            {
                konekcija.Close();
            }
            //upit koji služi za popunjavanje ListView-a
            string select = "SELECT r.rezervacija_id, m.ime+' '+m.prezime,CONVERT(NVARCHAR(10), r.pocetak_rezervacije, 103), " +
                "ABS(DATEDIFF(day, r.pocetak_rezervacije, r.kraj_rezervacije)), r.suma_za_uplatu,CONVERT(NVARCHAR(10), r.rok_za_uplatu, 103), " +
                "r.suma_za_uplatu-@suma";
            string from = "FROM rezervacija r INNER JOIN musterija m ON r.musterija_id=m.musterija_id";
            string where = "WHERE r.rezervacija_id=@rezervacija_id1";
            komanda.CommandText = select + " " + from + " " + where;
            komanda.Parameters.AddWithValue("@suma",suma);
            komanda.Parameters.AddWithValue("@rezervacija_id1", rezervacija_id);
            da.SelectCommand = komanda;
            da.Fill(dt1);
            label5.Text = "Ugovor broj: " + dt1.Rows[0][0] +
                "\nUgovorač: " + dt1.Rows[0][1] +
                "\nPočetak usluge: " + dt1.Rows[0][2] +
                "\nBroj dana: " + dt1.Rows[0][3] +
                "\nUkupan iznos: " + dt1.Rows[0][4] +
                "\nRok za uplatu: " + dt1.Rows[0][5] +
                "\nDug: " + dt1.Rows[0][6];
            dug = Convert.ToInt32(dt1.Rows[0][6]);
            if (Convert.ToInt32(dt1.Rows[0][6]) == 0)
            {
                button1.Enabled = textBox1.Enabled = comboBox2.Enabled = false;
            }
            else
            {
                button1.Enabled = textBox1.Enabled = comboBox2.Enabled = true;
            }
            dt1.Clear();
            listView1.Columns.Add("Rata", 60);
            listView1.Columns.Add("Iznos", 80);
            listView1.Columns.Add("Način plaćanja", 160);
            listView1.View = View.Details;
            listView1.GridLines = true;
            select = "SELECT uplata.iznos,nacin_placanja.nacin_placanja";
            from = "FROM uplata INNER JOIN nacin_placanja ON uplata.nacin_placanja_id = nacin_placanja.nacin_placanja_id";
            where = "WHERE uplata.rezervacija_id=@rezervacija_id2";
            komanda.CommandText = select + " " + from + " " + where;
            komanda.Parameters.AddWithValue("@rezervacija_id2", rezervacija_id);
            da.SelectCommand = komanda;
            da.Fill(dt2);
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                string[] podaci = { 
                    //odredjivanje rate
                    (i + 1).ToString(),
                    dt2.Rows[i][0].ToString(),
                    dt2.Rows[i][1].ToString() 
                };
                ListViewItem stavka = new ListViewItem(podaci);
                listView1.Items.Add(stavka);
            }
        }
        int uplata_id;
        DateTime rok_isplate;
        private void button1_Click(object sender, EventArgs e)
        {
            Konekcija();
            //odredjivanje roka isplate
            komanda.CommandText = "SELECT rok_za_uplatu FROM rezervacija WHERE rezervacija_id=@rezervacija_id1";
            komanda.Parameters.AddWithValue("@rezervacija_id1", rezervacija_id);
            try
            {
                konekcija.Open();
                rok_isplate = Convert.ToDateTime(komanda.ExecuteScalar());
            }
            catch
            {
                MessageBox.Show("Greška!");
            }
            finally
            {
                konekcija.Close();
                komanda.CommandText = "";
            }
            //ne mozemo da uplacujemo nakon sto je istekao rok za isplatu
            if (DateTime.Now <= rok_isplate)
            {
                komanda.CommandText = "SELECT COUNT(uplata_id) FROM uplata";
                try
                {
                    konekcija.Open();
                    //odredjivanje ID za insertovanje u bazu
                    uplata_id = Convert.ToInt32(komanda.ExecuteScalar()) + 1;
                }
                catch
                {
                    MessageBox.Show("GREŠKA!");
                }
                finally
                {
                    konekcija.Close();
                    komanda.CommandText = "";
                }
                if (textBox1.Text == string.Empty || comboBox2.SelectedIndex<0)
                {
                    MessageBox.Show("Morate uneti iznos koji uplaćujete i način kojim plaćate.", "UPOZORENjE!");
                }
                //ne mozemo uplatiti veću sumu od one koju dugujemo
                else if (Convert.ToInt32(textBox1.Text) <= dug)
                {
                    int iznos = Convert.ToInt32(textBox1.Text);
                    int nacin_placanja_id = comboBox2.SelectedIndex + 1;
                    string insert = "INSERT INTO uplata(uplata_id, rezervacija_id,nacin_placanja_id,iznos, datum_uplate)";
                    string values = "VALUES(@uplata_id, @rezervacija_id2,@nacin_placanja_id, @iznos, CONVERT(DATETIME, @datum, 104))";
                    komanda.CommandText = insert + " " + values;
                    komanda.Parameters.AddWithValue("@uplata_id", uplata_id);
                    komanda.Parameters.AddWithValue("@rezervacija_id2", rezervacija_id);
                    komanda.Parameters.AddWithValue("@nacin_placanja_id", nacin_placanja_id);
                    komanda.Parameters.AddWithValue("@iznos", iznos);
                    DateTime now=DateTime.Now;
                    string datum = now.ToShortDateString();
                    komanda.Parameters.AddWithValue("@datum", datum);
                    try
                    {
                        konekcija.Open();
                        komanda.ExecuteNonQuery();
                        MessageBox.Show("Uspešno ste izvršili plaćanje", "OBAVEŠTENjE");
                        comboBox1_SelectedIndexChanged(sender, e);
                    }
                    catch
                    {
                        MessageBox.Show("Greška pri plaćanju.", "UPOZORENjE!");
                    }
                    finally
                    {
                        konekcija.Close();
                        textBox1.Text = string.Empty;
                        comboBox2.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show("Ne možete uplatiti sumu veću od one koju dugujete.", "UPOZORENjE!");
                }
            }
            else
            {
                MessageBox.Show("Rok za vašu isplatu je istekao!", "UPOZORENjE!!!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
