﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotelse_rezervacije
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
            dataGridView1.RowHeadersVisible = false;
        }
        SqlConnection konekcija;
        SqlDataAdapter da;
        SqlCommand komanda;
        DataTable dt1;
        void Konekcija()
        {
            konekcija = new SqlConnection();
            //konekcija.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=""Hotelske rezervacije"";Integrated Security=True;";
            konekcija.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=hoteli;Integrated Security=True;";
            komanda = new SqlCommand();
            komanda.Connection = konekcija;
            dt1 = new DataTable();
            da = new SqlDataAdapter();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        int ukupno;
        int dostupno;

        private void button1_Click(object sender, EventArgs e)
        {
            Konekcija();
            dostupno = 0;
            //krajnji datum ne sme biti manji od pocetnog
            if (monthCalendar1.SelectionStart <= monthCalendar2.SelectionStart && monthCalendar1.SelectionEnd <= monthCalendar2.SelectionEnd)
            {
                //provera da li je pocetni odnosno krajnji datum izmedju pocetka i kraja rezervacije u bazi i obrnuto, tj. vršena je dupla provera
                string select = "SELECT DISTINCT soba.soba_id AS No, tip_sobe.tip_sobe AS 'Tip Sobe', soba.sprat AS Sprat";
                string join1 = "FROM rezervacija INNER JOIN rezervacija_sobe ON rezervacija.rezervacija_id = rezervacija_sobe.rezervacija_id";
                string join2 = "INNER JOIN soba ON rezervacija_sobe.soba_id = soba.soba_id";
                string join3 = "INNER JOIN tip_sobe ON soba.tip_sobe_id = tip_sobe.tip_sobe_id";
                string where = "WHERE rezervacija.pocetak_rezervacije NOT BETWEEN @pocetak AND @kraj AND " +
                    "rezervacija.kraj_rezervacije NOT BETWEEN @pocetak AND @kraj AND " +
                    "@pocetak NOT BETWEEN rezervacija.pocetak_rezervacije AND rezervacija.kraj_rezervacije AND " +
                    "@kraj NOT BETWEEN rezervacija.pocetak_rezervacije AND rezervacija.kraj_rezervacije";
                string order = "ORDER BY soba.soba_id ASC";
                komanda.CommandText = select + " " + join1 + " " + join2 + " " + join3 + " " + where + " " + order;
                komanda.Parameters.AddWithValue("@pocetak", monthCalendar1.SelectionStart);
                komanda.Parameters.AddWithValue("@kraj", monthCalendar2.SelectionEnd);
                da.SelectCommand = komanda;
                da.Fill(dt1);
                dataGridView1.DataSource = dt1;
                for (int i = 0; i < dt1.Columns.Count; i++)
                    dataGridView1.Columns[i].Width = dataGridView1.Width / 3 - 6;
                //odredjivanja broja dostupnih soba za izabran termin
                foreach (DataRow dr in dt1.Rows)
                    dostupno++;
                label4.Text = "Dostupni kapaciteti: " + dostupno;
            }
            else
            {
                MessageBox.Show("Pogrešno izabran datum!", "Greška!");
            }
        }

        private void Booking_Load(object sender, EventArgs e)
        {
            Konekcija();
            //ukupan broj soba u hotelu
            komanda.CommandText = "SELECT COUNT(soba_id) FROM soba";
            try
            {
                konekcija.Open();
                ukupno =Convert.ToInt32(komanda.ExecuteScalar());
                label3.Text += ukupno.ToString() + " soba";
            }
            catch
            {
                MessageBox.Show("Greška!");
            }
            finally
            {
                komanda.CommandText = "";
                konekcija.Close();
            }
            //ispis svih soba u DataGridView-u
            string select = "SELECT s.soba_id AS No , ts.tip_sobe AS 'Tip Sobe' , s.sprat AS Sprat";
            string from = "FROM soba s INNER JOIN tip_sobe ts ON s.tip_sobe_id=ts.tip_sobe_id";
            komanda.CommandText = select + " " + from;
            da.SelectCommand = komanda;
            da.Fill(dt1);
            dataGridView1.DataSource = dt1;
            for (int i = 0; i < dt1.Columns.Count; i++) 
            {
                dataGridView1.Columns[i].Width = dataGridView1.Width / 3 - 6;
            }
        }
    }
}
