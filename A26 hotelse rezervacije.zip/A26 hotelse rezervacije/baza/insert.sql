INSERT INTO tip_sobe
VALUES(1,'jednokrevetna')

INSERT INTO tip_sobe
VALUES(2,'dvokrevetna')

INSERT INTO tip_sobe
VALUES(3,'trokrevetna')

INSERT INTO tip_sobe
VALUES(4,'četvorokrevetna')

INSERT INTO tip_sobe
VALUES(5,'petokrevetna')

-------------------------------------------------------------------------------------------------------------------------------

INSERT INTO gost
VALUES(1,'Nikola','Pavicevic','Dositejeva 33','nikolapavicevic90@gmail.com','064/322-0222',CONVERT(DATETIME, '10-01-2001',105))

INSERT INTO gost
VALUES(2,'Stefan','Mitrovic','Dositejeva 33','stefanmitrovic@gmail.com','069-632-069',CONVERT(DATETIME, '12-05-1999',105))

INSERT INTO gost
VALUES(3,'Milutin','Gojkovic','Karadjordjeva 45','milutingojkovic15@gmail.com','063/222-729',CONVERT(DATETIME, '05-12-1987',105))

INSERT INTO gost
VALUES(4,'Uros','Petrovic','Cara Lazara 13','petrovicuros00@gmail.com','064/488-388-4',CONVERT(DATETIME, '14-05-2000',105))

INSERT INTO gost
VALUES(5,'Marija','Ruzic','Milosa Obilica 15','marija.ruzic@yahoo.com','064/488-3-884',CONVERT(DATETIME, '11-09-1986',105))

INSERT INTO gost
VALUES(6,'Danijela','Markovic','Karadjordjeva 12','markovicdanijela@gmail.com','065/439-439-0',CONVERT(DATETIME, '26-04-1975',105))

INSERT INTO gost
VALUES(7,'Nikola','Stanic','Cara Dusana 14','stanicccnikola@gmail.com','069-673-069',CONVERT(DATETIME, '14-07-1999',105))

INSERT INTO gost
VALUES(8,'Milan','Obradovic','Karadjordjeva 133','milanobradovic@gmail.com','062/45-8838',CONVERT(DATETIME, '31-12-1998',105))

INSERT INTO gost
VALUES(9,'Dragana','Sreckovic','Hajduk Veljkova 22','sreckovic.dragana111@gmail.com','064/333-68-86',CONVERT(DATETIME, '09-10-1971',105))

INSERT INTO gost
VALUES(10,'Perica','Peric','Dositejeva 10','pericaperic1234','063/296-222',CONVERT(DATETIME, '03-03-1982',105))

INSERT INTO gost
VALUES(11,'Dragan','Drazic','Dositejeva 34','draziiicdragan@gmail.com','065/40-500-04',CONVERT(DATETIME, '16-08-1979',105))

INSERT INTO gost
VALUES(12,'Milica','Mikic','Cara Dusana 56','milica.mikic@gmail.com','064/3335-350',CONVERT(DATETIME, '02-02-1981',105))

INSERT INTO gost
VALUES(13,'Slobodan','Dakic','Heroja Maricica 20','dakicslobodan@gmail.com','066/5-849-849',CONVERT(DATETIME, '01-02-1977',105))

INSERT INTO gost
VALUES(14,'Jana','Dasic','Jug Bogdanova 3','jana.dasic.@gmail.com','065/422-3222',CONVERT(DATETIME, '29-06-1995',105))

INSERT INTO gost
VALUES(15,'Predrag','Garic','Jug Bogdanova 22','garicpredrag@gmail.com','064/34-700-70',CONVERT(DATETIME, '26-04-1991',105))

INSERT INTO gost
VALUES(16,'Stefan','Stefanovic','Zicka 13','stefstefanoviicc@gmail.com','063-590-063',CONVERT(DATETIME, '10-05-1996',105))

INSERT INTO gost
VALUES(17,'Marina','Lazovic','Obiliceva 65','lazoviceva423@gmail.com','064/4-380-381',CONVERT(DATETIME, '22-05-2000',105))

INSERT INTO gost
VALUES(18,'Jelena','Krstic','Vojvode Stepe 13','krsticjelena12@gmail.com','069/3-345-345',CONVERT(DATETIME, '11-12-1988',105))

INSERT INTO gost
VALUES(19,'Djordje','Jovanovic','Rada Vilotijevica 20','jovanovicdjordje444@gmail.com','066/50-44-333',CONVERT(DATETIME, '01-01-1998',105))

INSERT INTO gost
VALUES(20,'Kosta','Pavicevic','Dositejeva 33','kostakosta32kosta@gmail.com','063/76-81-885',CONVERT(DATETIME, '15-02-1995',105))

INSERT INTO gost
VALUES(21,'Milan','Lučić','Vojvode Stepe 4','lucic11@gmail.com','064/312-4474',CONVERT(DATETIME, '11-11-2000',105))

INSERT INTO gost
VALUES(22,'Milutin','Ivković','Heroja Maričića 21','milutinaccc@gmail.com','062/53-54-316',CONVERT(DATETIME, '09-09-1990',105))

INSERT INTO gost
VALUES(23,'Mihajlo','Živković','Hilandarska BB','m.zivkovic@gmail.com','063/54-62-645',CONVERT(DATETIME, '15-11-2001',105))

INSERT INTO gost
VALUES(24,'Nikola','Lazić','Jug Bogdanova 90','nikolalazic11@gmail.com','063/223-5848',CONVERT(DATETIME, '02-04-1999',105))

INSERT INTO gost
VALUES(25,'Ana','Živković','Jug Bogdanova 33','azivkovic04@gmail.com','065/562-5896',CONVERT(DATETIME, '12-10-2004',105))

INSERT INTO gost
VALUES(26,'Jovana','Božović','Petra Lekovića 32','jovanabozovic11@gmail.com','069/523-4587',CONVERT(DATETIME, '11-06-2004',105))

INSERT INTO gost
VALUES(27,'Marko','Timotijević','Žička 14','timotije@gmail.com','060/258-7531',CONVERT(DATETIME, '15-11-1988',105))

INSERT INTO gost
VALUES(28,'Miloje','Arsić','Vrba BB','arsicmiloje@gmail.com','069/256-9517',CONVERT(DATETIME, '22-05-1970',105))

INSERT INTO gost
VALUES(29,'Milena','Dravić','Heroja Maričića 11','dravic22@hotmail.com','063/235-7824',CONVERT(DATETIME, '12-12-1998',105))

INSERT INTO gost
VALUES(30,'Milica','Dabović','Karadjordjeva 34','milicadabovic21@live.com','063/128-7825',CONVERT(DATETIME, '21-05-1980',105))

INSERT INTO gost
VALUES(31,'Marija','Milović','Obilićeva 6','mmilovic@gmail.com','069/564-2000',CONVERT(DATETIME, '06-06-2001',105))

INSERT INTO gost
VALUES(32,'Veljko','Kostović','Rudarska 39','kosta12@gmail.com','064/468-6400',CONVERT(DATETIME, '19-07-2004',105))

INSERT INTO gost
VALUES(33,'Nikola','Krsmanović','Trešnjarska 55','nikolakrsmanovic342@live.com','067/597-2596',CONVERT(DATETIME, '23-02-2004',105))

INSERT INTO gost
VALUES(34,'Sara','Vesković','Jug Bogdanova 12','veskovics34@gmail.com','067/258-4578',CONVERT(DATETIME, '01-02-1987',105))

INSERT INTO gost
VALUES(35,'Petar','Pavlović','Zelengora 22','petarrr@hotmail.com','061/128-7825',CONVERT(DATETIME, '22-08-2002',105))

INSERT INTO gost
VALUES(36,'Milan','Dobrić','Srećka Andrića 4','dobric@gmail.com','066/025-2254',CONVERT(DATETIME, '25-09-1968',105))

INSERT INTO gost
VALUES(37,'Miloš','Veljović','Zmaj Jovina 17','mveljovic@gmail.com','062/128-7429',CONVERT(DATETIME, '02-11-1994',105))

INSERT INTO gost
VALUES(38,'Stefan','Stefanović','Dositejeva 44','sstefanovic@gmail.com','065/258-4287',CONVERT(DATETIME, '12-12-2008',105))

INSERT INTO gost
VALUES(39,'Andrej','Marković','Živojina Mišića 25','andrejmarkovic33@live.com','063/129-1574',CONVERT(DATETIME, '15-09-2009',105))

INSERT INTO gost
VALUES(40,'Nikolina','Nikolić','Vojvode Stepe 42','nikolicn@hotmail.com','069/128-7452',CONVERT(DATETIME, '25-07-1988',105))

INSERT INTO gost
VALUES(41,'Simona','Zdravković','Solunskih boraca 23','zdravkovic70@gmail.com','062/146-1248',CONVERT(DATETIME, '30-06-2010',105))

INSERT INTO gost
VALUES(42,'Anja','Andrić','Hajduk Veljkova 54','aandric@live.com','069/456-7256',CONVERT(DATETIME, '23-09-2005',105))

INSERT INTO gost
VALUES(43,'Milica','Marković','Hilandarska 11','markovicmilica@live.com','064/125-1287',CONVERT(DATETIME, '13-01-2004',105))

INSERT INTO gost
VALUES(44,'Dušan','Milunović','Miloša Velikog 12','milunovic21@gmail.com','069/157-1357',CONVERT(DATETIME, '09-04-1964',105))

INSERT INTO gost
VALUES(45,'Boško','Trifunović','Zelengora 32','boskotrifunovic03','062/178-4839',CONVERT(DATETIME, '21-10-2003',105))

INSERT INTO gost
VALUES(46,'Sofija','Radulović','Tanaska Rajića 64','radulovics50@gmail.com','065/697-2225',CONVERT(DATETIME, '26-05-2005',105))

INSERT INTO gost
VALUES(47,'Djordje','Luković','Omladinska 41','lukovic15@gmail.com','067/125-7364',CONVERT(DATETIME, '06-05-2004',105))

INSERT INTO gost
VALUES(48,'Lidija','Vitakić','Beogradska 90','lidijavitakic22@live.com','064/187-236',CONVERT(DATETIME, '22-02-2003',105))

INSERT INTO gost
VALUES(49,'Kristina','Krstić','Dositeja Obradovića 32','kkrstic05@hotmail.com','069/257-2548',CONVERT(DATETIME, '01-02-2005',105))

INSERT INTO gost
VALUES(50,'Ksenija','Vojinović','Ribničkih partizana 2','ksenijavojinovic04@gmail.com','064/572-0284',CONVERT(DATETIME, '30-12-2004',105))

--------------------------------------NOVI PRIMERI-----------------------------------------------------------------------------------------------------
INSERT INTO gost
VALUES(51,'Nikola','Rogonjić','Omladinska 75','nrogonjic@gmail.com','066/582-4728',CONVERT(DATETIME, '10-09-2004',105))

INSERT INTO gost
VALUES(52,'Oliver','Bošković','Vojvode Živojina Mišića 73','oli@live.com','064/193-8532',CONVERT(DATETIME, '12-12-1999',105))

INSERT INTO gost
VALUES(53,'Staša','Despotović','Žička 45','stasadespotovic@gmail.com','064/528-3278',CONVERT(DATETIME, '02-02-1988',105))

INSERT INTO gost
VALUES(54,'Ekatarina','Savić','Beogradska 88','ekatarina@hotmail.com','062/159-7531',CONVERT(DATETIME, '03-05-1994',105))

INSERT INTO gost
VALUES(55,'Filip','Terzić','Rudarska 66','filipterzic@gmail.com','064/782-4258',CONVERT(DATETIME, '15-01-2000',105))

INSERT INTO gost
VALUES(56,'Dejan','Živković','Dositeja Obradovića 52','zivkvicd@gmail.com','066/248-9512',CONVERT(DATETIME, '18-03-2001',105))

INSERT INTO gost
VALUES(57,'Aleksa','Stevanović','Zmaj Jovina 17','aleksastevanovic02@gmail.com','069/456-1289',CONVERT(DATETIME, '14-11-2002',105))

INSERT INTO gost
VALUES(58,'Stevan','Stanišić','Dositejeva 153','stevans@gmail.com','065/149-6425',CONVERT(DATETIME, '16-08-1997',105))

INSERT INTO gost
VALUES(59,'Jana','Vukanović','Hajduk Veljkova 43','janavukanovic@gmail.com','068/439-1684',CONVERT(DATETIME, '10-10-2001',105))

INSERT INTO gost
VALUES(60,'Marina','Petrović','Karadjordjeva 65','mpetrovic@gmail.com','065/156-1245',CONVERT(DATETIME, '27-05-2001',105))

-------------------------------------------------------------------------------------------------------------------

INSERT INTO musterija
VALUES(1,'Nikola','Pavicevic','Dositejeva 33','nikolapavicevic90@gmail.com','064/322-0222',CONVERT(DATETIME, '10-01-2001',105))

INSERT INTO musterija
VALUES(2,'Stefan','Mitrovic','Dositejeva 33','stefanmitrovic@gmail.com','069-632-069',CONVERT(DATETIME, '12-05-1999',105))

INSERT INTO musterija
VALUES(3,'Milutin','Gojkovic','Karadjordjeva 45','milutingojkovic15@gmail.com','063/222-729',CONVERT(DATETIME, '05-12-1987',105))

INSERT INTO musterija
VALUES(4,'Uros','Petrovic','Cara Lazara 13','petrovicuros00@gmail.com','064/488-388-4',CONVERT(DATETIME, '14-05-2000',105))

INSERT INTO musterija
VALUES(5,'Marija','Ruzic','Milosa Obilica 15','marija.ruzic@yahoo.com','064/488-3-884',CONVERT(DATETIME, '11-09-1986',105))

INSERT INTO musterija
VALUES(6,'Danijela','Markovic','Karadjordjeva 12','markovicdanijela@gmail.com','065/439-439-0',CONVERT(DATETIME, '26-04-1975',105))

INSERT INTO musterija
VALUES(7,'Nikola','Stanic','Cara Dusana 14','stanicccnikola@gmail.com','069-673-069',CONVERT(DATETIME, '14-07-1999',105))

INSERT INTO musterija
VALUES(8,'Milan','Obradovic','Karadjordjeva 133','milanobradovic@gmail.com','062/45-8838',CONVERT(DATETIME, '31-12-1998',105))

INSERT INTO musterija
VALUES(9,'Dragana','Sreckovic','Hajduk Veljkova 22','sreckovic.dragana111@gmail.com','064/333-68-86',CONVERT(DATETIME, '09-10-1971',105))

INSERT INTO musterija
VALUES(10,'Perica','Peric','Dositejeva 10','pericaperic1234@live.com','063/296-222',CONVERT(DATETIME, '03-03-1982',105))

INSERT INTO musterija
VALUES(11,'Dragan','Drazic','Dositejeva 34','draziiicdragan@gmail.com','065/40-500-04',CONVERT(DATETIME, '16-08-1979',105))

INSERT INTO musterija
VALUES(12,'Milica','Mikic','Cara Dusana 56','milica.mikic@gmail.com','064/3335-350',CONVERT(DATETIME, '02-02-1981',105))

INSERT INTO musterija
VALUES(13,'Slobodan','Dakic','Heroja Maricica 20','dakicslobodan@gmail.com','066/5-849-849',CONVERT(DATETIME, '01-02-1977',105))

INSERT INTO musterija
VALUES(14,'Jana','Dasic','Jug Bogdanova 3','jana.dasic.@gmail.com','065/422-3222',CONVERT(DATETIME, '29-06-1995',105))

INSERT INTO musterija
VALUES(15,'Predrag','Garic','Jug Bogdanova 22','garicpredrag@gmail.com','064/34-700-70',CONVERT(DATETIME, '26-04-1991',105))

INSERT INTO musterija
VALUES(16,'Stefan','Stefanovic','Zicka 13','stefstefanoviicc@gmail.com','063-590-063',CONVERT(DATETIME, '10-05-1996',105))

INSERT INTO musterija
VALUES(17,'Marina','Lazovic','Obiliceva 65','lazoviceva423@gmail.com','064/4-380-381',CONVERT(DATETIME, '22-05-2000',105))

INSERT INTO musterija
VALUES(18,'Jelena','Krstic','Vojvode Stepe 13','krsticjelena12@gmail.com','069/3-345-345',CONVERT(DATETIME, '11-12-1988',105))

INSERT INTO musterija
VALUES(19,'Djordje','Jovanovic','Rada Vilotijevica 20','jovanovicdjordje444@gmail.com','066/50-44-333',CONVERT(DATETIME, '01-01-1998',105))

INSERT INTO musterija
VALUES(20,'Kosta','Pavicevic','Dositejeva 33','kostakosta32kosta@gmail.com','063/76-81-885',CONVERT(DATETIME, '15-02-1995',105))

INSERT INTO musterija
VALUES(21,'Milan','Lučić','Vojvode Stepe 4','lucic11@gmail.com','064/312-4474',CONVERT(DATETIME, '11-11-2000',105))

INSERT INTO musterija
VALUES(22,'Milutin','Ivković','Heroja Maričića 21','milutinaccc@gmail.com','062/53-54-316',CONVERT(DATETIME, '09-09-1990',105))

INSERT INTO musterija
VALUES(23,'Mihajlo','Živković','Hilandarska BB','m.zivkovic@gmail.com','063/54-62-645',CONVERT(DATETIME, '15-11-2001',105))

INSERT INTO musterija
VALUES(24,'Nikola','Lazić','Jug Bogdanova 90','nikolalazic11@gmail.com','063/223-5848',CONVERT(DATETIME, '02-04-1999',105))

INSERT INTO musterija
VALUES(25,'Ana','Živković','Jug Bogdanova 33','azivkovic04@gmail.com','065/562-5896',CONVERT(DATETIME, '12-10-2004',105))

INSERT INTO musterija
VALUES(26,'Jovana','Božović','Petra Lekovića 32','jovanajacovic11@gmail.com','069/523-4587',CONVERT(DATETIME, '11-06-2004',105))

INSERT INTO musterija
VALUES(27,'Marko','Timotijević','Žička 14','timotije@gmail.com','060/258-7531',CONVERT(DATETIME, '15-11-1988',105))

INSERT INTO musterija
VALUES(28,'Miloje','Arsić','Vrba BB','arsicmiloje@gmail.com','069/256-9517',CONVERT(DATETIME, '22-05-1970',105))

INSERT INTO musterija
VALUES(29,'Milena','Dravić','Heroja Maričića 11','dravic22@hotmail.com','063/235-7824',CONVERT(DATETIME, '12-12-1998',105))

INSERT INTO musterija
VALUES(30,'Milica','Dabović','Karadjordjeva 34','milicadabovic21@live.com','063/128-7825',CONVERT(DATETIME, '21-05-1980',105))

INSERT INTO musterija
VALUES(31,'Marija','Milović','Obilićeva 6','mmilovic@gmail.com','069/564-2000',CONVERT(DATETIME, '06-06-2001',105))

INSERT INTO musterija
VALUES(32,'Veljko','Kostović','Rudarska 39','kosta12@gmail.com','064/468-6400',CONVERT(DATETIME, '19-07-2004',105))

INSERT INTO musterija
VALUES(33,'Nikola','Krsmanović','Trešnjarska 55','nikolakrsmanovic342@live.com','067/597-2596',CONVERT(DATETIME, '23-02-2004',105))

INSERT INTO musterija
VALUES(34,'Sara','Spasojević','Žička 24','saraspasojevic32@gmail.com','065/021-5438',CONVERT(DATETIME, '15-03-2004',105))

INSERT INTO musterija
VALUES(35,'Andjela','Bažalac','Cara Dušana 65','bazalaca@live.com','061/256-2354',CONVERT(DATETIME, '02-06-2000',105))

INSERT INTO musterija
VALUES(36,'Vuk','Simić','Cara Lazara 32','vuksimic@gmail.com','063/458-1257',CONVERT(DATETIME, '21-04-1999',105))

INSERT INTO musterija
VALUES(37,'Vanja','Čalamać','Kordinska 23','vanjaa@gmail.com','064/527-3647',CONVERT(DATETIME, '25-08-2002',105))

INSERT INTO musterija
VALUES(38,'Nevena','Gvozdenović','Olge Jovičić Rite 10','nevenagvozdenovic45@gmail.com','062/258-7153',CONVERT(DATETIME, '29-01-1999',105))

INSERT INTO musterija
VALUES(39,'Anica','Rafailović','IV Kraljevački bataljon 53','rafailovicca@hotmail.com','069/258-4103',CONVERT(DATETIME, '15-10-2000',105))

INSERT INTO musterija
VALUES(40,'Milan','Srdić','Hilandarska 22','milansrdic@live.com','064/012-7541',CONVERT(DATETIME, '11-11-1998',105))

INSERT INTO musterija
VALUES(41,'Jelena','Golubović','Oktobarskih žrtava 41','jelenagolubovic11@gmail.com','069/546-3475',CONVERT(DATETIME, '12-05-1990',105))

INSERT INTO musterija
VALUES(42,'Tamara','Sofijanić','Palih boraca 77','sofijanic80@gmail.com','062/146-2015',CONVERT(DATETIME, '01-06-1995',105))

INSERT INTO musterija
VALUES(43,'Miloš','Domanović','Dositejeva 61','domanovic44@hotmail.com','066/024-1876',CONVERT(DATETIME, '20-10-1996',105))

INSERT INTO musterija
VALUES(44,'Dalibor','Šašić','Jug Bogdanova 80','sasic04@live.com','061/429-7513',CONVERT(DATETIME, '03-03-2004',105))

INSERT INTO musterija
VALUES(45,'Boško','Dimitrijević','Vojvode Stepe Stepanovića 35','boskodimitrijevic@gmail.com','069/176-5389',CONVERT(DATETIME, '27-04-1977',105))

------------------------------------------NOVI PRIMERI-------------------------------------------------------------------------------------------------------

INSERT INTO musterija
VALUES(46,'Sara','Košanin','Tanaska Rajića 32','kosanin@gmail.com','064/124-1345',CONVERT(DATETIME, '15-12-2000',105))

INSERT INTO musterija
VALUES(47,'Magdalena','Bošković','Obilićeva 64','mboskovic@gmail.com','064/128-7425',CONVERT(DATETIME, '12-08-2003',105))

INSERT INTO musterija
VALUES(48,'Lazar','Vukadinović','Hilandarska 90','lazarvukadinovic04@gmail.com','062/124-4512',CONVERT(DATETIME, '25-12-2000',105))

INSERT INTO musterija
VALUES(49,'Aljoša','Gršić','Olge Jovičić Rita 1','gršić@gmail.com','062/154-7456',CONVERT(DATETIME, '13-07-2001',105))

INSERT INTO musterija
VALUES(50,'Jana','Božanović','Beogradska 222','bozanovic@gmail.com','062/534-7512',CONVERT(DATETIME, '01-03-1995',105))

INSERT INTO musterija
VALUES(51,'Ognjen','Marković','Mila Marića 32','ogi@gmail.com','062/854-3256',CONVERT(DATETIME, '01-03-1980',105))

INSERT INTO musterija
VALUES(52,'Anja','Rumenić','Vojvode Putnika 94','rumenic09@gmail.com','062/258-1435',CONVERT(DATETIME, '02-02-2000',105))

INSERT INTO musterija
VALUES(53,'Marta','Marilović','Radomira Putnika 12','mmarilovic@gmail.com','065/2436-1587',CONVERT(DATETIME, '05-08-2000',105))

INSERT INTO musterija
VALUES(54,'Lazar','Pavlović','IV Kaljevački bataljon 47','lazarp@gmail.com','061/2453-1254',CONVERT(DATETIME, '12-08-2004',105))

INSERT INTO musterija
VALUES(55,'Aleksandra','Vujović','Dositejeva 78','valeksandra@gmail.com','062/9569-8855',CONVERT(DATETIME, '25-09-2001',105))

INSERT INTO musterija
VALUES(56,'Teodora','Bogdanovski','Solunskih Boraca 29','bogdanovskit@gmail.com','069/2233-1212',CONVERT(DATETIME, '01-01-2001',105))

INSERT INTO musterija
VALUES(57,'Djordje','Milunović','Hilandarska 90','milunovic@gmail.com','065/428-7852',CONVERT(DATETIME, '05-05-2003',105))

INSERT INTO musterija
VALUES(58,'Mihailo','Mitrović','Jug Bogdanova 74','mikimitrovic@gmail.com','066/6655-2200',CONVERT(DATETIME, '13-05-1989',105))

INSERT INTO musterija
VALUES(59,'Iva','Radović','Cara Lazara 15','ivar@gmail.com','064/1123-4512',CONVERT(DATETIME, '16-09-1985',105))

INSERT INTO musterija
VALUES(60,'Nemanja','Petrović','Cara Dušana 60','nemkep@gmail.com','061/4565-4477',CONVERT(DATETIME, '07-11-1994',105))

-----------------------------------------------------------------------------------------------------------------------------------
INSERT INTO nacin_placanja
VALUES(1,'gotovinsko')

INSERT INTO nacin_placanja
VALUES(2,'platna kartica')

INSERT INTO nacin_placanja
VALUES(3,'čekovima gradjana')

INSERT INTO nacin_placanja
VALUES(4,'kredit')

------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO rezervacija
VALUES(1,3,CONVERT(DATETIME, '12.05.2020', 104),CONVERT(DATETIME, '20.07.2020', 104),CONVERT(DATETIME, '27.07.2020', 104),CONVERT(DATETIME, '27.07.2020', 104),'20000') 

INSERT INTO rezervacija
VALUES(2,6,CONVERT(DATETIME, '01.01.2020', 104),CONVERT(DATETIME, '05.01.2020', 104),CONVERT(DATETIME, '10.01.2020', 104),CONVERT(DATETIME, '10.01.2020', 104),'15000')  

INSERT INTO rezervacija
VALUES(3,12,CONVERT(DATETIME, '05.06.2020', 104),CONVERT(DATETIME, '10.06.2020', 104),CONVERT(DATETIME, '17.06.2020', 104),CONVERT(DATETIME, '17.06.2020', 104),'20000')  

INSERT INTO rezervacija
VALUES(4,11,CONVERT(DATETIME, '03.03.2019', 104),CONVERT(DATETIME, '05.03.2019', 104),CONVERT(DATETIME, '08.03.2019', 104),CONVERT(DATETIME, '08.03.2019', 104),'10000')  

INSERT INTO rezervacija
VALUES(5,20,CONVERT(DATETIME, '01.05.2020', 104),CONVERT(DATETIME, '21.05.2020', 104),CONVERT(DATETIME, '27.07.2020', 104),CONVERT(DATETIME, '30.07.2020', 104),'18000')    

INSERT INTO rezervacija
VALUES(6,15,CONVERT(DATETIME, '08.09.2018', 104),CONVERT(DATETIME, '10.09.2018', 104),CONVERT(DATETIME, '17.09.2018', 104),CONVERT(DATETIME, '17.09.2018', 104),'20000')    

INSERT INTO rezervacija
VALUES(7,6,CONVERT(DATETIME, '15.11.2020', 104),CONVERT(DATETIME, '20.11.2020', 104),CONVERT(DATETIME, '25.11.2020', 104),CONVERT(DATETIME, '25.11.2020', 104),'15000')   

INSERT INTO rezervacija
VALUES(8,16,CONVERT(DATETIME, '03.12.2019', 104),CONVERT(DATETIME, '06.12.2019', 104),CONVERT(DATETIME, '10.12.2019', 104),CONVERT(DATETIME, '10.12.2019', 104),'12000')   

INSERT INTO rezervacija
VALUES(9,7,CONVERT(DATETIME, '01.12.2020', 104),CONVERT(DATETIME, '30.12.2020', 104),CONVERT(DATETIME, '05.01.2021', 104),CONVERT(DATETIME, '05.01.2021', 104),'18000')    

INSERT INTO rezervacija
VALUES(10,9,CONVERT(DATETIME, '01.04.2017', 104),CONVERT(DATETIME, '15.04.2017', 104),CONVERT(DATETIME, '20.04.2017', 104),CONVERT(DATETIME, '20.04.2017', 104),'15000')     

INSERT INTO rezervacija
VALUES(11,10,CONVERT(DATETIME, '17.05.2020', 104),CONVERT(DATETIME, '20.05.2020', 104),CONVERT(DATETIME, '30.05.2020', 104),CONVERT(DATETIME, '30.05.2020', 104),'25000')    

INSERT INTO rezervacija
VALUES(12,19,CONVERT(DATETIME, '07.09.2019', 104),CONVERT(DATETIME, '15.09.2019', 104),CONVERT(DATETIME, '20.09.2019', 104),CONVERT(DATETIME, '20.09.2019', 104),'15000')     

INSERT INTO rezervacija
VALUES(13,13,CONVERT(DATETIME, '28.06.2018', 104),CONVERT(DATETIME, '01.07.2019', 104),CONVERT(DATETIME, '06.07.2019', 104),CONVERT(DATETIME, '06.07.2019', 104),'15000')    

INSERT INTO rezervacija
VALUES(14,14,CONVERT(DATETIME, '12.02.2019', 104),CONVERT(DATETIME, '15.02.2019', 104),CONVERT(DATETIME, '20.02.2019', 104),CONVERT(DATETIME, '20.02.2019', 104),'15000')    

INSERT INTO rezervacija
VALUES(15,2,CONVERT(DATETIME, '12.07.2020', 104),CONVERT(DATETIME, '18.07.2020', 104),CONVERT(DATETIME, '25.07.2020', 104),CONVERT(DATETIME, '25.07.2020', 104),'20000')    

INSERT INTO rezervacija
VALUES(16,4,CONVERT(DATETIME, '20.12.2020', 104),CONVERT(DATETIME, '03.01.2021', 104),CONVERT(DATETIME, '07.01.2021', 104),CONVERT(DATETIME, '07.01.2021', 104),'12000')    

INSERT INTO rezervacija
VALUES(17,8,CONVERT(DATETIME, '25.03.2017', 104),CONVERT(DATETIME, '30.03.2017', 104),CONVERT(DATETIME, '05.04.2017', 104),CONVERT(DATETIME, '05.04.2017', 104),'18000')    

INSERT INTO rezervacija
VALUES(18,15,CONVERT(DATETIME, '09.10.2020', 104),CONVERT(DATETIME, '15.10.2020', 104),CONVERT(DATETIME, '20.10.2020', 104),CONVERT(DATETIME, '20.10.2020', 104),'15000')     

INSERT INTO rezervacija
VALUES(19,17,CONVERT(DATETIME, '07.07.2019', 104),CONVERT(DATETIME, '10.07.2019', 104),CONVERT(DATETIME, '17.07.2019', 104),CONVERT(DATETIME, '17.07.2019', 104),'20000')  

INSERT INTO rezervacija
VALUES(20,18,CONVERT(DATETIME, '15.10.2020', 104),CONVERT(DATETIME, '23.10.2020', 104),CONVERT(DATETIME, '30.10.2020', 104),CONVERT(DATETIME, '30.10.2020', 104),'20000')    

INSERT INTO rezervacija
VALUES(21,21,CONVERT(DATETIME, '22.3.2023', 104),CONVERT(DATETIME, '30.3.2023', 104),CONVERT(DATETIME, '4.4.2023', 104),CONVERT(DATETIME, '15.5.2023', 104),'16000')  

INSERT INTO rezervacija
VALUES(22,24,CONVERT(DATETIME, '1.5.2023', 104),CONVERT(DATETIME, '25.5.2023', 104),CONVERT(DATETIME, '1.6.2023', 104),CONVERT(DATETIME, '1.6.2023', 104),'30000')    

INSERT INTO rezervacija
VALUES(23,22,CONVERT(DATETIME, '29.4.2023', 104),CONVERT(DATETIME, '2.6.2023', 104),CONVERT(DATETIME, '12.6.2023', 104),CONVERT(DATETIME, '15.6.2023', 104),'35000')  

INSERT INTO rezervacija
VALUES(24,30,CONVERT(DATETIME, '05.05.2023', 104),CONVERT(DATETIME, '10.05.2023', 104),CONVERT(DATETIME, '15.05.2023', 104),CONVERT(DATETIME, '15.05.2023', 104),'28000') 

INSERT INTO rezervacija
VALUES(25,35,CONVERT(DATETIME, '03.04.2023', 104),CONVERT(DATETIME, '15.04.2023', 104),CONVERT(DATETIME, '21.04.2023', 104),CONVERT(DATETIME, '25.04.2023', 104),'25000') 

INSERT INTO rezervacija
VALUES(26,40,CONVERT(DATETIME, '12.04.2022', 104),CONVERT(DATETIME, '15.07.2022', 104),CONVERT(DATETIME, '18.07.2022', 104),CONVERT(DATETIME, '18.08.2023', 104),'18000') 

INSERT INTO rezervacija
VALUES(27,45,CONVERT(DATETIME, '20.03.2023', 104),CONVERT(DATETIME, '30.03.2023', 104),CONVERT(DATETIME, '05.04.2023', 104),CONVERT(DATETIME, '10.04.2023', 104),'21000') 

INSERT INTO rezervacija
VALUES(28,31,CONVERT(DATETIME, '04.05.2023', 104),CONVERT(DATETIME, '10.05.2023', 104),CONVERT(DATETIME, '16.05.2023', 104),CONVERT(DATETIME, '16.06.2023', 104),'30000') 

INSERT INTO rezervacija
VALUES(29,36,CONVERT(DATETIME, '29.04.2023', 104),CONVERT(DATETIME, '05.05.2023', 104),CONVERT(DATETIME, '07.05.2023', 104),CONVERT(DATETIME, '10.05.2023', 104),'12000') 

INSERT INTO rezervacija
VALUES(30,41,CONVERT(DATETIME, '05.01.2023', 104),CONVERT(DATETIME, '15.01.2023', 104),CONVERT(DATETIME, '18.01.2023', 104),CONVERT(DATETIME, '18.01.2023', 104),'10000') 

INSERT INTO rezervacija
VALUES(31,37,CONVERT(DATETIME, '15.04.2023', 104),CONVERT(DATETIME, '14.05.2023', 104),CONVERT(DATETIME, '19.05.2023', 104),CONVERT(DATETIME, '25.05.2023', 104),'32000') 

INSERT INTO rezervacija
VALUES(32,42,CONVERT(DATETIME, '02.02.2022', 104),CONVERT(DATETIME, '03.03.2022', 104),CONVERT(DATETIME, '8.3.2022', 104),CONVERT(DATETIME, '10.3.2022', 104),'18000') 

INSERT INTO rezervacija
VALUES(33,25,CONVERT(DATETIME, '20.04.2023', 104),CONVERT(DATETIME, '01.06.2023', 104),CONVERT(DATETIME, '05.06.2023', 104),CONVERT(DATETIME, '15.06.2023', 104),'35000') 

INSERT INTO rezervacija
VALUES(34,44,CONVERT(DATETIME, '15.03.2023', 104),CONVERT(DATETIME, '10.08.2023', 104),CONVERT(DATETIME, '13.08.2023', 104),CONVERT(DATETIME, '15.08.2023', 104),'15000') 

INSERT INTO rezervacija
VALUES(35,29,CONVERT(DATETIME, '05.05.2023', 104),CONVERT(DATETIME, '10.06.2023', 104),CONVERT(DATETIME, '16.06.2023', 104),CONVERT(DATETIME, '20.06.2023', 104),'20000') 

INSERT INTO rezervacija
VALUES(36,32,CONVERT(DATETIME, '15.03.2023', 104),CONVERT(DATETIME, '22.05.2023', 104),CONVERT(DATETIME, '28.05.2023', 104),CONVERT(DATETIME, '30.05.2023', 104),'35000') 

INSERT INTO rezervacija
VALUES(37,24,CONVERT(DATETIME, '21.04.2023', 104),CONVERT(DATETIME, '25.05.2023', 104),CONVERT(DATETIME, '30.05.2023', 104),CONVERT(DATETIME, '03.06.2023', 104),'40000')

INSERT INTO rezervacija
VALUES(38,1,CONVERT(DATETIME, '20.03.2023', 104),CONVERT(DATETIME, '20.06.2023', 104),CONVERT(DATETIME, '23.06.2023', 104),CONVERT(DATETIME, '25.06.2023', 104),'15000') 

INSERT INTO rezervacija
VALUES(39,38,CONVERT(DATETIME, '11.02.2023', 104),CONVERT(DATETIME, '30.07.2023', 104),CONVERT(DATETIME, '03.08.2023', 104),CONVERT(DATETIME, '10.08.2023', 104),'27000') 

INSERT INTO rezervacija
VALUES(40,37,CONVERT(DATETIME, '13.04.2023', 104),CONVERT(DATETIME, '27.05.2023', 104),CONVERT(DATETIME, '30.05.2023', 104),CONVERT(DATETIME, '04.06.2023', 104),'23000') 

INSERT INTO rezervacija
VALUES(41,39,CONVERT(DATETIME, '15.04.2023', 104),CONVERT(DATETIME, '25.07.2023', 104),CONVERT(DATETIME, '30.07.2023', 104),CONVERT(DATETIME, '03.08.2023', 104),'22000') 

INSERT INTO rezervacija
VALUES(42,43,CONVERT(DATETIME, '26.04.2023', 104),CONVERT(DATETIME, '03.06.2023', 104),CONVERT(DATETIME, '06.06.2023', 104),CONVERT(DATETIME, '10.06.2023', 104),'21000') 

-----------------------------------------------------------NOVI PRIMERI---------------------------------------------

INSERT INTO rezervacija
VALUES(43,50,CONVERT(DATETIME, '15.05.2023', 104),CONVERT(DATETIME, '27.05.2023', 104),CONVERT(DATETIME, '07.06.2023', 104),CONVERT(DATETIME, '10.07.2023', 104),'30000')

INSERT INTO rezervacija
VALUES(44,56,CONVERT(DATETIME, '10.04.2023', 104),CONVERT(DATETIME, '02.05.2023', 104),CONVERT(DATETIME, '15.05.2023', 104),CONVERT(DATETIME, '20.05.2023', 104),'35000')

INSERT INTO rezervacija
VALUES(45,46,CONVERT(DATETIME, '20.05.2023', 104),CONVERT(DATETIME, '28.07.2023', 104),CONVERT(DATETIME, '03.08.2023', 104),CONVERT(DATETIME, '05.08.2023', 104),'22000')

INSERT INTO rezervacija
VALUES(46,60,CONVERT(DATETIME, '23.05.2023', 104),CONVERT(DATETIME, '18.10.2023', 104),CONVERT(DATETIME, '21.10.2023', 104),CONVERT(DATETIME, '30.10.2023', 104),'18000')

INSERT INTO rezervacija
VALUES(47,49,CONVERT(DATETIME, '18.05.2023', 104),CONVERT(DATETIME, '08.08.2023', 104),CONVERT(DATETIME, '18.08.2023', 104),CONVERT(DATETIME, '23.08.2023', 104),'35000')

INSERT INTO rezervacija
VALUES(48,55,CONVERT(DATETIME, '01.06.2023', 104),CONVERT(DATETIME, '10.09.2023', 104),CONVERT(DATETIME, '15.09.2023', 104),CONVERT(DATETIME, '20.09.2023', 104),'32000')

INSERT INTO rezervacija
VALUES(49,47,CONVERT(DATETIME, '29.05.2023', 104),CONVERT(DATETIME, '30.06.2023', 104),CONVERT(DATETIME, '06.07.2023', 104),CONVERT(DATETIME, '10.07.2023', 104),'42000')

INSERT INTO rezervacija
VALUES(50,54,CONVERT(DATETIME, '25.04.2023', 104),CONVERT(DATETIME, '16.11.2023', 104),CONVERT(DATETIME, '18.11.2023', 104),CONVERT(DATETIME, '18.11.2023', 104),'12000')

INSERT INTO rezervacija
VALUES(51,59,CONVERT(DATETIME, '22.05.2023', 104),CONVERT(DATETIME, '30.08.2023', 104),CONVERT(DATETIME, '05.09.2023', 104),CONVERT(DATETIME, '10.09.2023', 104),'28000')

INSERT INTO rezervacija
VALUES(52,48,CONVERT(DATETIME, '03.03.2023', 104),CONVERT(DATETIME, '15.05.2023', 104),CONVERT(DATETIME, '25.05.2023', 104),CONVERT(DATETIME, '30.05.2023', 104),'50000')

INSERT INTO rezervacija
VALUES(53,58,CONVERT(DATETIME, '08.02.2023', 104),CONVERT(DATETIME, '17.09.2023', 104),CONVERT(DATETIME, '19.09.2023', 104),CONVERT(DATETIME, '21.09.2023', 104),'20000')

INSERT INTO rezervacija
VALUES(54,52,CONVERT(DATETIME, '10.04.2023', 104),CONVERT(DATETIME, '14.07.2023', 104),CONVERT(DATETIME, '15.07.2023', 104),CONVERT(DATETIME, '15.07.2023', 104),'4000')

INSERT INTO rezervacija
VALUES(55,51,CONVERT(DATETIME, '11.04.2023', 104),CONVERT(DATETIME, '16.11.2023', 104),CONVERT(DATETIME, '22.11.2023', 104),CONVERT(DATETIME, '24.11.2023', 104),'38000')

INSERT INTO rezervacija
VALUES(56,57,CONVERT(DATETIME, '16.05.2023', 104),CONVERT(DATETIME, '25.06.2023', 104),CONVERT(DATETIME, '01.07.2023', 104),CONVERT(DATETIME, '05.07.2023', 104),'32000')

INSERT INTO rezervacija
VALUES(57,53,CONVERT(DATETIME, '18.05.2023', 104),CONVERT(DATETIME, '28.12.2023', 104),CONVERT(DATETIME, '02.01.2024', 104),CONVERT(DATETIME, '15.01.2023', 104),'40000')

-----------------------------------------------------------------------------------------------------

INSERT INTO uplata
VALUES(1,1,4,20000)

INSERT INTO uplata
VALUES(2,2,1,15000)

INSERT INTO uplata
VALUES(3,3,1,20000)

INSERT INTO uplata
VALUES(4,4,4,10000)

INSERT INTO uplata
VALUES(5,5,3,18000)

INSERT INTO uplata
VALUES(6,6,3,20000)

INSERT INTO uplata
VALUES(7,7,2,15000)

INSERT INTO uplata
VALUES(8,8,4,12000)

INSERT INTO uplata
VALUES(9,9,1,18000)

INSERT INTO uplata
VALUES(10,10,1,15000)

INSERT INTO uplata
VALUES(11,11,1,25000)

INSERT INTO uplata
VALUES(12,12,1,15000)

INSERT INTO uplata
VALUES(13,13,3,15000)

INSERT INTO uplata
VALUES(14,14,2,15000)

INSERT INTO uplata
VALUES(15,15,2,20000)

INSERT INTO uplata
VALUES(16,16,3,12000)

INSERT INTO uplata
VALUES(17,17,4,18000)

INSERT INTO uplata
VALUES(18,18,1,15000)

INSERT INTO uplata
VALUES(19,19,2,20000)

INSERT INTO uplata
VALUES(20,20,3,20000)

INSERT INTO uplata
VALUES(21,25,1,5000)

INSERT INTO uplata
VALUES(22,42,2,2500)

INSERT INTO uplata
VALUES(23,30,4,3000)

INSERT INTO uplata
VALUES(24,31,3,3500)

INSERT INTO uplata
VALUES(25,25,3,3200)

INSERT INTO uplata
VALUES(26,24,1,4500)

INSERT INTO uplata
VALUES(27,37,1,5000)

INSERT INTO uplata
VALUES(28,23,1,5000)

INSERT INTO uplata
VALUES(29,31,4,6000)

INSERT INTO uplata
VALUES(30,30,3,5000)

INSERT INTO uplata
VALUES(31,41,2,4000)

INSERT INTO uplata
VALUES(32,26,3,4500)

INSERT INTO uplata
VALUES(33,23,1,3000)

INSERT INTO uplata
VALUES(34,28,1,2000)

INSERT INTO uplata
VALUES(35,31,1,2350)

INSERT INTO uplata
VALUES(36,42,3,7000)

INSERT INTO uplata
VALUES(37,29,1,6500)

INSERT INTO uplata
VALUES(38,28,2,7500)

INSERT INTO uplata
VALUES(39,37,1,8200)

INSERT INTO uplata
VALUES(40,28,4,3500)

INSERT INTO uplata
VALUES(41,26,3,2800)

INSERT INTO uplata
VALUES(42,26,2,3000)

INSERT INTO uplata
VALUES(43,36,1,3600)

INSERT INTO uplata
VALUES(44,42,2,4500)

INSERT INTO uplata
VALUES(45,40,3,6500)

INSERT INTO uplata
VALUES(46,28,1,6500)

INSERT INTO uplata
VALUES(47,38,4,3200)

INSERT INTO uplata
VALUES(48,36,4,3500)

INSERT INTO uplata
VALUES(49,27,2,5000)

INSERT INTO uplata
VALUES(50,42,2,7500)

--------------------------NOVI PRIMERI-----------------------------------------

INSERT INTO uplata
VALUES(51,25,2,5000)

INSERT INTO uplata
VALUES(52,43,4,6500)

INSERT INTO uplata
VALUES(53,55,1,12000)

INSERT INTO uplata
VALUES(54,45,3,3000)

INSERT INTO uplata
VALUES(55,28,4,4000)

INSERT INTO uplata
VALUES(56,36,1,3500)

INSERT INTO uplata
VALUES(57,57,1,2500)

INSERT INTO uplata
VALUES(58,28,2,3000)

INSERT INTO uplata
VALUES(59,36,3,3000)

INSERT INTO uplata
VALUES(60,56,4,5000)

INSERT INTO uplata
VALUES(61,28,3,6000)

INSERT INTO uplata
VALUES(62,44,2,6200)

INSERT INTO uplata
VALUES(63,46,3,5800)

INSERT INTO uplata
VALUES(64,36,1,6500)

INSERT INTO uplata
VALUES(65,44,2,3500)

INSERT INTO uplata
VALUES(66,39,2,2500)

INSERT INTO uplata
VALUES(67,29,3,4000)

INSERT INTO uplata
VALUES(68,55,4,5000)

INSERT INTO uplata
VALUES(69,51,3,3500)

INSERT INTO uplata
VALUES(70,46,1,7000)

----------------------------------------------------------------------------

INSERT INTO soba
VALUES(1,2,1,'Apartman')

INSERT INTO soba
VALUES(2,1,3,'Ima terasu')

INSERT INTO soba
VALUES(3,5,2,'Apartman')

INSERT INTO soba
VALUES(4,3,2,'Obična')

INSERT INTO soba
VALUES(5,2,3,'Bračna')

INSERT INTO soba
VALUES(6,2,4,'Bračna')

INSERT INTO soba
VALUES(7,3,1,'Predsednički apartman')

INSERT INTO soba
VALUES(8,1,1,'Obična')

INSERT INTO soba
VALUES(9,5,2,'Ima terasu')

INSERT INTO soba
VALUES(10,4,3,'Ima terasu')

INSERT INTO soba
VALUES(11,2,3,'Nema terasu')

INSERT INTO soba
VALUES(12,2,4,'Bračna')

INSERT INTO soba
VALUES(13,1,3,'Apartman')

INSERT INTO soba
VALUES(14,4,2,'Velika površina')

INSERT INTO soba
VALUES(15,5,1,'Đakuzi')

INSERT INTO soba
VALUES(16,2,2,'Bračna')

INSERT INTO soba
VALUES(17,4,4,'Obična')

INSERT INTO soba
VALUES(18,5,3,'Predsednički apartman')

INSERT INTO soba
VALUES(19,3,3,'Obična')

INSERT INTO soba
VALUES(20,1,1,'Obična')

INSERT INTO soba
VALUES(21,1,1,'Đakuzi')

INSERT INTO soba
VALUES(22,3,2,'Obična')

INSERT INTO soba
VALUES(23,2,4,'Predsednički apartman')

INSERT INTO soba
VALUES(24,1,4,'Obična')

INSERT INTO soba
VALUES(25,2,1,'Obična')

INSERT INTO soba
VALUES(26,4,2,'Đakuzi')

INSERT INTO soba
VALUES(27,1,4,'Ima terasu')

INSERT INTO soba
VALUES(28,4,3,'Đakuzi')

INSERT INTO soba
VALUES(29,2,1,'Apartman')

INSERT INTO soba
VALUES(30,5,4,'Nema terasu')

INSERT INTO soba
VALUES(31,1,2,'Bračna')

INSERT INTO soba
VALUES(32,3,1,'Obična')

INSERT INTO soba
VALUES(33,5,4,'Obična')

INSERT INTO soba
VALUES(34,3,3,'Ima terasu')

INSERT INTO soba
VALUES(35,1,1,'Bračna')

INSERT INTO soba
VALUES(36,2,3,'Đakuzi')

INSERT INTO soba
VALUES(37,4,2,'Ima terasu')

INSERT INTO soba
VALUES(38,4,4,'Apartman')

INSERT INTO soba
VALUES(39,5,3,'Velika površina')

INSERT INTO soba
VALUES(40,1,2,'Bračna')
----------------------------NOVI PRIMERI-----------------------------------------------

INSERT INTO soba
VALUES(41,1,1,'Bračna')

INSERT INTO soba
VALUES(42,3,2,'Đakuzi')

INSERT INTO soba
VALUES(43,5,3,'Velika površina')

INSERT INTO soba
VALUES(44,2,2,'Ima terasu')

INSERT INTO soba
VALUES(45,2,1,'Apartman')

INSERT INTO soba
VALUES(46,4,4,'Đakuzi')

INSERT INTO soba
VALUES(47,4,3,'Velika površina')

INSERT INTO soba
VALUES(48,2,2,'Ima terasu')

INSERT INTO soba
VALUES(49,5,4,'Đakuzi')

INSERT INTO soba
VALUES(50,1,3,'Bračna')

INSERT INTO soba
VALUES(51,3,2,'Velika površina')

INSERT INTO soba
VALUES(52,1,2,'Bračna')

INSERT INTO soba
VALUES(53,2,1,'Đakuzi')

INSERT INTO soba
VALUES(54,3,2,'Ima terasu')

INSERT INTO soba
VALUES(55,4,2,'Apartman')

INSERT INTO soba
VALUES(56,5,3,'Đakuzi')

INSERT INTO soba
VALUES(57,4,3,'Obična')

INSERT INTO soba
VALUES(58,2,1,'Apartman')

INSERT INTO soba
VALUES(59,3,1,'Velika površina')

INSERT INTO soba
VALUES(60,1,4,'Bračna')

INSERT INTO soba
VALUES(61,2,3,'Ima terasu')

INSERT INTO soba
VALUES(62,5,4,'Đakuzi')

INSERT INTO soba
VALUES(63,3,3,'Velika površina')

INSERT INTO soba
VALUES(64,5,2,'Ima terasu')

INSERT INTO soba
VALUES(65,2,4,'Obična')

INSERT INTO soba
VALUES(66,2,3,'Apartman')

INSERT INTO soba
VALUES(67,1,4,'Bračna')

INSERT INTO soba
VALUES(68,2,1,'Đakuzi')

INSERT INTO soba
VALUES(69,1,2,'Velika površina')

INSERT INTO soba
VALUES(70,1,4,'Bračna')

----------------------------------------------------------

INSERT INTO rezervacija_sobe
VALUES(1,9,12)

INSERT INTO rezervacija_sobe
VALUES(2,18,5)

INSERT INTO rezervacija_sobe
VALUES(3,19,9)

INSERT INTO rezervacija_sobe  
VALUES(4,7,16)

INSERT INTO rezervacija_sobe
VALUES(5,17,13)

INSERT INTO rezervacija_sobe
VALUES(6,1,18)

INSERT INTO rezervacija_sobe
VALUES(7,8,7)

INSERT INTO rezervacija_sobe
VALUES(8,10,3)

INSERT INTO rezervacija_sobe
VALUES(9,16,1)

INSERT INTO rezervacija_sobe
VALUES(10,2,10)

INSERT INTO rezervacija_sobe
VALUES(11,18,14)

INSERT INTO rezervacija_sobe
VALUES(12,3,6)

INSERT INTO rezervacija_sobe
VALUES(13,6,20)

INSERT INTO rezervacija_sobe
VALUES(14,11,17)

INSERT INTO rezervacija_sobe
VALUES(15,12,4)

INSERT INTO rezervacija_sobe
VALUES(16,5,19)

INSERT INTO rezervacija_sobe
VALUES(17,13,8)

INSERT INTO rezervacija_sobe
VALUES(18,14,15)

INSERT INTO rezervacija_sobe
VALUES(19,4,8)

INSERT INTO rezervacija_sobe
VALUES(20,5,11)

INSERT INTO rezervacija_sobe
VALUES(21,21,21)

INSERT INTO rezervacija_sobe
VALUES(22,26,24)

INSERT INTO rezervacija_sobe
VALUES(23,24,22)

INSERT INTO rezervacija_sobe
VALUES(38,4,25)

INSERT INTO rezervacija_sobe
VALUES(41,15,50)

INSERT INTO rezervacija_sobe
VALUES(25,20,28)

INSERT INTO rezervacija_sobe
VALUES(34,22,47)

INSERT INTO rezervacija_sobe
VALUES(20,23,31)

INSERT INTO rezervacija_sobe
VALUES(31,25,44)

INSERT INTO rezervacija_sobe
VALUES(35,27,34)

INSERT INTO rezervacija_sobe
VALUES(36,40,41)

INSERT INTO rezervacija_sobe
VALUES(28,37,37)

INSERT INTO rezervacija_sobe
VALUES(31,28,29)

INSERT INTO rezervacija_sobe
VALUES(27,39,46)

INSERT INTO rezervacija_sobe
VALUES(24,29,32)

INSERT INTO rezervacija_sobe
VALUES(37,38,43)

INSERT INTO rezervacija_sobe
VALUES(26,32,35)

INSERT INTO rezervacija_sobe
VALUES(42,36,40)

INSERT INTO rezervacija_sobe
VALUES(39,30,30)

INSERT INTO rezervacija_sobe
VALUES(29,35,33)

INSERT INTO rezervacija_sobe
VALUES(33,31,36)

INSERT INTO rezervacija_sobe
VALUES(36,33,39)

INSERT INTO rezervacija_sobe
VALUES(28,34,27)

-------------------------------------NOVI PRIMERI--------------------------------------------

INSERT INTO rezervacija_sobe
VALUES(53,56,12)

INSERT INTO rezervacija_sobe
VALUES(46,46,10)

INSERT INTO rezervacija_sobe
VALUES(57,43,27)

INSERT INTO rezervacija_sobe
VALUES(50,54,5)

INSERT INTO rezervacija_sobe
VALUES(43,49,30)

INSERT INTO rezervacija_sobe
VALUES(45,69,35)

INSERT INTO rezervacija_sobe
VALUES(56,63,47)

INSERT INTO rezervacija_sobe
VALUES(49,51,58)

INSERT INTO rezervacija_sobe
VALUES(52,47,59)

INSERT INTO rezervacija_sobe
VALUES(47,41,51)

INSERT INTO rezervacija_sobe
VALUES(54,65,13)

INSERT INTO rezervacija_sobe
VALUES(44,70,17)

INSERT INTO rezervacija_sobe
VALUES(55,57,2)

INSERT INTO rezervacija_sobe
VALUES(51,48,23)

INSERT INTO rezervacija_sobe
VALUES(48,44,17)


------------------------------------------------------------------------------

INSERT INTO dodatak
VALUES(1,4,'Televizor,internet')

INSERT INTO dodatak
VALUES(2,18,'Televizor,internet')

INSERT INTO dodatak
VALUES(3,1,'Televizor')

INSERT INTO dodatak
VALUES(4,10,'Mini bar,televizor')

INSERT INTO dodatak
VALUES(5,5,'Televizor')

INSERT INTO dodatak
VALUES(6,3,'Internet,televizor')

INSERT INTO dodatak
VALUES(7,9,'Televizor,telefon')

INSERT INTO dodatak
VALUES(8,6,'Televizor,mini bar')

INSERT INTO dodatak
VALUES(9,7,'Televizor,mini bar')

INSERT INTO dodatak
VALUES(10,8,'Televizor')

INSERT INTO dodatak
VALUES(11,13,'Televizor,mini bar')

INSERT INTO dodatak
VALUES(12,11,'Mini bar')

INSERT INTO dodatak
VALUES(13,12,'Internet,mini bar')

INSERT INTO dodatak
VALUES(14,14,'Internet')

INSERT INTO dodatak
VALUES(15,15,'Telefon')

INSERT INTO dodatak
VALUES(16,2,'Televizor,telefon')

INSERT INTO dodatak
VALUES(17,16,'Internet,telefon')

INSERT INTO dodatak
VALUES(18,17,'Televizor,mini bar')

INSERT INTO dodatak
VALUES(19,20,'Televizor, mini bar')

INSERT INTO dodatak
VALUES(20,19,'Internet, televizor')

INSERT INTO dodatak
VALUES(21,40,'Internet, televizor, mini bar')

INSERT INTO dodatak
VALUES(22,35,'Fen za kosu, internet, televizor')

INSERT INTO dodatak
VALUES(23,30,'Internet, mini bar')

INSERT INTO dodatak
VALUES(24,25,'Televizor, internet')

INSERT INTO dodatak
VALUES(25,39,'Fen za kosu, mini bar, televizor')

INSERT INTO dodatak
VALUES(26,34,'Fen za kosu, mini bar, televizor, internet')

INSERT INTO dodatak
VALUES(27,29,'Televizor, internet')

INSERT INTO dodatak
VALUES(28,24,'Fen za kosu, internet, televizor')

INSERT INTO dodatak
VALUES(29,38,'Televizor, mini bar')

INSERT INTO dodatak
VALUES(30,33,'Fen za kosu, internet, televizor')

INSERT INTO dodatak
VALUES(31,28,'Televizor, internet')

INSERT INTO dodatak
VALUES(32,23,'Fen za kosu, mini bar, televizor, internet')

INSERT INTO dodatak
VALUES(33,37,'Televizor,telefon')

INSERT INTO dodatak
VALUES(34,32,'Internet, televizor, mini bar')

INSERT INTO dodatak
VALUES(35,27,'Fen za kosu, internet, televizor')

INSERT INTO dodatak
VALUES(36,22,'Televizor,telefon')

INSERT INTO dodatak
VALUES(37,36,'Televizor, internet')

INSERT INTO dodatak
VALUES(38,31,'Fen za kosu, mini bar, televizor, internet')

INSERT INTO dodatak
VALUES(39,26,'Televizor, mini bar')

INSERT INTO dodatak
VALUES(40,21,'Fen za kosu, internet, televizor')